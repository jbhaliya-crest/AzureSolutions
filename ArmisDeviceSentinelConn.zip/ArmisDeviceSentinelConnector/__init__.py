"""This __init__ file will be called once the trigger is generated."""

import datetime
import logging
import azure.functions as func
import time
from ..SharedCode.armis_client import ArmisDevice
from Exceptions.ArmisExceptions import (
    ArmisException,
    ArmisDataNotFoundException,
    ArmisTimeOutException,
)

HTTP_ERRORS = {
    400: "Armis Device Connector: Bad request: Missing aql parameter.",
    401: "Armis Device Connector: Authentication error: Authorization information is missing or invalid.",
}
ERROR_MESSAGES = {
    "ACCESS_TOKEN_NOT_FOUND": "Armis Device Connector: Access token not found. please check Key.",
    "HOST_CONNECTION_ERROR": "Armis Device Connector: Invalid host while verifying 'armis account'.",
}


def check_data_exists_or_not_device(armis_obj: ArmisDevice):
    """Check_data_exists_or_not is to check if the data is exists or not."""
    try:
        armis_obj._fetch_device_data()
    except ArmisTimeOutException:
        logging.info(
            "Armis Device Connector: 9:30 mins executed hence stopping the execution"
        )
        return
    except ArmisDataNotFoundException:
        raise
    except ArmisException as err:
        logging.error(err)
        raise ArmisException(
            "Armis Device Connector: Error occured during checking whether log table exist or not."
        )

def main(mytimer: func.TimerRequest) -> None:
    """
    Start the execution.

    Args:
        mytimer (func.TimerRequest): This variable will be used to trigger the function.

    """
    utc_timestamp = (
        datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
    )
    logging.info(
        "Armis Device Connector: Python timer trigger function ran at %s",
        utc_timestamp,
    )

    start_time = time.time()
    try:
        armis_obj = ArmisDevice(start_time)
        check_data_exists_or_not_device(armis_obj)
    except ArmisDataNotFoundException:
        pass

    utc_timestamp_final = (
        datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
    )
    logging.info(
        "Armis Device Connector: execution completed for device at %s.",
        utc_timestamp_final,
    )

    end_time = time.time()
    logging.info(f"Armis Device Connector: Total time taken is {(end_time - start_time):.3f} seconds.")

    if mytimer.past_due:
        logging.info("Armis Device Connector: The timer is past due!")
