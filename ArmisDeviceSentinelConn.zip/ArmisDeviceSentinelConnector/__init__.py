"""This __init__ file will be called once the trigger is generated."""

import datetime
import logging
from math import log
from socketserver import DatagramRequestHandler
import azure.functions as func
import base64
import hashlib
import hmac
import json
import os
import time
import requests
import csv
import io
import zipfile
from .state_manager import StateManager
from .exports_store import ExportsTableStore
from .keyvault_secrets_management import KeyVaultSecretManager
from Exceptions.ArmisExceptions import (
    ArmisException,
    ArmisDataNotFoundException,
    ArmisTimeOutException,
)


API_KEY = os.environ["ArmisSecretKey"]
url = os.environ["ArmisURL"]
connection_string = os.environ["AzureWebJobsStorage"]
customer_id = os.environ["WorkspaceID"]
shared_key = os.environ["WorkspaceKey"]
armis_devices_table_name = os.environ["ArmisDeviceTableName"]

HTTP_ERRORS = {
    400: "Armis Device Connector: Bad request: Missing aql parameter.",
    401: "Armis Device Connector: Authentication error: Authorization information is missing or invalid.",
}
ERROR_MESSAGES = {
    "ACCESS_TOKEN_NOT_FOUND": "Armis Device Connector: Access token not found. please check Key.",
    "HOST_CONNECTION_ERROR": "Armis Device Connector: Invalid host while verifying 'armis account'.",
}

CHECKPOINT_TABLE_NAME = "ArmisDeviceCheckpoint"

# Report status constants
REPORT_STATUS_CREATED = "created"
REPORT_STATUS_RUNNING = "running"
REPORT_STATUS_FAILED = "failed"
REPORT_STATUS_TIMEOUT = "timeout"
REPORT_STATUS_SUCCESS = "success"

# Failure reasons
FAILURE_REASON_API_ERROR = "armis_api_error"
FAILURE_REASON_SENTINEL_ERROR = "sentinel_api_error"
FAILURE_REASON_TIMEOUT = "function_timeout"

MAX_RETRY = 5
FUNCTION_APP_TIMEOUT_SECONDS = 570
body = ""


class ArmisDevice:
    """This class will process the Device data and post it into the Microsoft sentinel."""

    def __init__(self, start_time):
        """__init__ method will initialize object of class."""
        self.start_time = start_time
        self._link = url
        self._header = {}
        self._secret_key = API_KEY
        self.checkpoint_table = None
        self._initialize_checkpoint_table()

    def _initialize_checkpoint_table(self):
        """Initialize the checkpoint table for tracking report status."""
        try:
            self.checkpoint_table = ExportsTableStore(connection_string, CHECKPOINT_TABLE_NAME)
        except Exception as err:
            logging.error(f"Failed to initialize checkpoint table: {err}")
            raise

    def _update_report_status(self, report_id, status, failure_reason=None, error_details=None):
        """Update the status of a report in the checkpoint table.

        Args:
            report_id (str): The ID of the report
            status (str): Current status of the report (created, running, failed, timeout, success)
            failure_reason (str, optional): Reason for failure if status is failed/timeout
            error_details (str, optional): Detailed error message if available
        """
        try:
            entity = {
                'PartitionKey': 'report',
                'RowKey': str(report_id),
                'status': status,
                'failure_reason': failure_reason or '',
                'error_details': error_details or '',
                'timestamp': datetime.datetime.utcnow().isoformat()
            }
            self.checkpoint_table.merge('report', str(report_id), entity)
            logging.info(f"Updated report {report_id} status to {status}")
        except Exception as err:
            logging.error(f"Failed to update report status in checkpoint table: {err}")

    def _get_failed_reports(self):
        """Get list of reports that failed or timed out and need to be retried.

        Returns:
            list: List of report IDs that need to be retried
        """
        try:
            failed_reports = []
            # Query for failed and timed out reports
            for status in [REPORT_STATUS_FAILED, REPORT_STATUS_TIMEOUT]:
                reports = self.checkpoint_table.query_entities(
                    f"PartitionKey eq 'report' and status eq '{status}'"
                )
                failed_reports.extend(reports)
            return failed_reports
        except Exception as err:
            logging.error(f"Failed to get failed reports from checkpoint table: {err}")
            return []

    def _get_access_token_device(self, armis_link_suffix):
        """
        _get_access_token_device will fetch the access token using api and set it in header for further use.

        Args:
            armis_link_suffix (String): This variable will be suffix/add-on to the link.

        """
        if self._secret_key is not None and self._link is not None:
            body = {"secret_key": self._secret_key}
            try:
                response = requests.post((self._link + armis_link_suffix), data=body)
                if response.status_code == 200:
                    logging.info("Armis Device Connector: Getting access token.")
                    response = response.json()
                    _access_token = response.get("data", {}).get("access_token")
                    self._header.update({"Authorization": _access_token})
                    self.keyvault_obj.set_keyvault_secret(self.access_token_key, _access_token)
                elif response.status_code == 400:
                    raise ArmisException(
                        "Armis Device Connector: Please check either armis URL or armis secret key is wrong."
                    )
                else:
                    raise ArmisException(
                        "Armis Device Connector: Error while generating the access token. Code: {} Message: {}.".format(
                            response.status_code, response.text
                        )
                    )
            except ArmisException as err:
                logging.error(err)
                raise ArmisException(
                    "Armis Device Connector: Error while generating the access token."
                )
        else:
            raise ArmisException(
                "Armis Device Connector: The secret key or link has not been initialized."
            )

    def validate_timestamp(self, last_seen_time):
        """function is used to validate the timestamp format. The timestamp should be in
        ISO 8601 format 'YYYY-MM-DDTHH:MM:SS'. If the timestamp is not in correct format, it will
        be formatted according to the given timestamp format.

        Args:
            last_seen_time (String): Timestamp string to be validated.

        Returns:
            String: Validated timestamp string.
        """
        try:
            if len(last_seen_time) != 19:
                if len(last_seen_time) == 10:
                    last_seen_time += "T00:00:00"
                    logging.info(
                        "Armis Device Connector: 'T:00:00:00' added as only date is available."
                    )
                else:
                    splited_time = last_seen_time.split("T")
                    if len(splited_time[1]) == 5:
                        splited_time[1] += ":00"
                        logging.info(
                            "Armis Device Connector: ':00' added as seconds not available."
                        )
                    elif len(splited_time[1]) == 2:
                        splited_time[1] += ":00:00"
                        logging.info(
                            "Armis Device Connector: ':00:00' added as only hour is available."
                        )
                    last_seen_time = "T".join(splited_time)
            return last_seen_time
        except Exception as err:
            logging.error("Armis Device Connector: Error occurred: {}".format(err))
            raise ArmisException(err)

    def parse_csv_file_to_python_dict(self, report_id, csv_data):
        """parse_csv_file_to_python_dict will parse the csv file and convert it to python dict."""
        desired_columns = [
            'MAC', 'Category', 'Name', 'Names', 'Model', 'Type', 'Risk', 'First Seen', 'Last Seen',
            'Brand', 'Users', 'Sensor', 'IPv4 Address', 'OS', 'OS Version', 'Tags', 'Location',
            'Boundaries', 'IPv6 Address', 'Site', 'Suspended', 'Tier', 'Alerts', 'Device ID',
            'Visibility', 'Data Sources', 'Access Switch', 'Purdue Level', 'Firmware Version', 'PLC Modules'
        ]

        def to_camel_case(column_name):
            words = column_name.split()
            return ''.join(word.capitalize() for word in words)

        # Process data in memory to efficiently transform CSV rows into Python dictionaries
        parse_start_time = time.time()
        filtered_data = []
        reader = csv.DictReader(io.StringIO(csv_data))
        for row in reader:
            filtered_row = {}
            for col in desired_columns:
                if int(time.time()) >= self.start_time + FUNCTION_APP_TIMEOUT_SECONDS:
                    self._update_report_status(report_id, REPORT_STATUS_TIMEOUT, FAILURE_REASON_TIMEOUT, "Function timeout while parsing CSV file")
                    raise ArmisTimeOutException()
                camel_col = to_camel_case(col)
                filtered_row[camel_col] = row.get(col, None)
            filtered_row['armis_device_time'] = row.get('Last Seen')
            filtered_data.append(filtered_row)

        parse_end_time = time.time()
        logging.info(
            "Armis Device Connector: Time taken to parse CSV data:"
            f"{(parse_end_time - parse_start_time):.3f} seconds."
        )
        return filtered_data

    def _get_device_data(self, report_payload):
        """Get_device_data is used to get data using api.
        Args:
            report_payload (dict): The payload for the report creation endpoint.
        Returns:
            list: List of device data dicts.
        """
        def get_report_headers():
            return {
                'Content-Type': 'application/json',
                'Authorization': self._header.get('Authorization', '')
            }

        report_gen_start_time = time.time()
        report_id = None
        # Create report
        for attempt in range(MAX_RETRY + 1):
            url = f"{self._link}/reports/"
            try:
                response = requests.post(url, data=json.dumps(report_payload), headers=get_report_headers())
                if response.status_code == 401:
                    logging.info("Armis Device Connector: Token expired. Getting new token.")
                    self._get_access_token_device("/access_token/")
                    continue
                response.raise_for_status()
                report_id = response.json()['data']['id']
                logging.info(f"Armis Device Connector: Report created with id '{report_id}'.")
                self._update_report_status(report_id, REPORT_STATUS_CREATED)
                break
            except requests.exceptions.HTTPError as e:
                error_msg = f"Failed to create report: {e}"
                if report_id:
                    self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_API_ERROR, error_msg)
                raise ArmisException(error_msg)
        else:
            error_msg = "Max retries exceeded while creating report."
            if report_id:
                self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_API_ERROR, error_msg)
            raise ArmisException(error_msg)

        # Run report
        run_url = f"{self._link}/reports/{report_id}/_run/"
        self._update_report_status(report_id, REPORT_STATUS_RUNNING)
        for attempt in range(MAX_RETRY + 1):
            try:
                response = requests.post(run_url, headers=get_report_headers())
                if response.status_code == 401:
                    self._get_access_token_device("/access_token/")
                    continue
                response.raise_for_status()
                if not response.json().get('success'):
                    error_msg = f"Failed to run report: {response.json()}"
                    self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_API_ERROR, error_msg)
                    raise ArmisException(error_msg)
                break
            except requests.exceptions.HTTPError as e:
                error_msg = f"Failed to run report: {e}"
                self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_API_ERROR, error_msg)
                raise ArmisException(error_msg)
        else:
            error_msg = "Max retries exceeded while running report."
            self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_API_ERROR, error_msg)
            raise ArmisException(error_msg)

        result_url = f"{self._link}/report-results/{report_id}/"
        s3_url = None

        # Poll for report readiness every 10 seconds for up to 3 minutes (18 attempts)
        logging.info("Armis Device Connector: Starting to poll for report readiness...")
        for attempt in range(18):
            if int(time.time()) >= self.start_time + FUNCTION_APP_TIMEOUT_SECONDS:
                self._update_report_status(report_id, REPORT_STATUS_TIMEOUT, FAILURE_REASON_TIMEOUT, "Function timeout while polling for report")
                raise ArmisTimeOutException()
            try:
                response = requests.get(result_url, headers=get_report_headers())
                if response.status_code == 401:
                    self._get_access_token_device("/access_token/")
                    continue
                response.raise_for_status()
                data = response.json()
                if data.get('success') and data.get('data', {}).get('url'):
                    s3_url = data['data']['url']
                    self._update_report_status(report_id, REPORT_STATUS_SUCCESS)
                    break
                elif not data.get('success'):
                    logging.info(f"Report not ready yet (attempt {attempt+1}/18): {data.get('message', '')}")
                    time.sleep(10)
                else:
                    error_msg = f"Unexpected response: {data}"
                    self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_API_ERROR, error_msg)
                    raise ArmisException(error_msg)
            except requests.exceptions.HTTPError as e:
                if response.status_code == 404:
                    logging.info(f"Report not ready yet (attempt {attempt+1}/18): 404 Not Found")
                    time.sleep(10)
                    continue
                error_msg = f"Failed to poll report result: {e}"
                self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_API_ERROR, error_msg)
                raise ArmisException(error_msg)
        if not s3_url:
            error_msg = "Report was not ready after 3 minutes."
            self._update_report_status(report_id, REPORT_STATUS_TIMEOUT, FAILURE_REASON_TIMEOUT, error_msg)
            raise ArmisTimeOutException(error_msg)

        # Download report using s3 url
        response = requests.get(s3_url)
        response.raise_for_status()

        report_gen_end_time = time.time()
        logging.info(f"Armis Device Connector: Time taken from preparing to downloading report: {(report_gen_end_time - report_gen_start_time):.3f} seconds.")

        # Extract csv file from zip
        csv_data = None
        with zipfile.ZipFile(io.BytesIO(response.content)) as z:
            for file_info in z.infolist():
                if file_info.filename.startswith("Armis Report") and file_info.filename.endswith(".csv"):
                    with z.open(file_info) as csvfile:
                        csv_data = csvfile.read().decode('utf-8')
                        break
        if not csv_data:
            raise ArmisException('No CSV file starting with "Armis Report" found in the ZIP.')

        return report_id, self.parse_csv_file_to_python_dict(report_id, csv_data)

    def _fetch_device_data(self):
        """Fetch_device_data is used to push all the data into table."""
        try:
            self.keyvault_obj = KeyVaultSecretManager()
            self.access_token_key = "armis-access-token"
            properties_list = self.keyvault_obj.get_properties_list_of_secrets()

            if self.access_token_key in properties_list:
                self.access_token = self.keyvault_obj.get_keyvault_secret(self.access_token_key)
                self._header.update({"Authorization": self.access_token})
            else:
                self._get_access_token_device("/access_token/")

            report_payload = {
                "asq": "in:devices timeFrame:\"14 Hours\"",
                "emailSubject": "Device Report",
                "reportName": f"DeviceReport-{int(time.time())}",
                "schedule": {
                    "email": ["dummy@dummy.com"],
                    "repeatAmount": "1",
                    "repeatUnit": "days",
                    "reportFileFormat": "csv",
                    "timezone": "Asia/Kolkata",
                    "timeOfDay": "15:00",
                },
                "format": "csv"
            }

            report_id, data = self._get_device_data(report_payload)

            azuresentinel = AzureSentinel()
            if data:
                logging.info("Armis Device Connector: Total length of data is %s ", len(data))
                try:
                    # Post data to Microsoft Sentinel
                    post_start_time = time.time()
                    azuresentinel.post_data(customer_id, json.dumps(data), armis_devices_table_name)
                    post_end_time = time.time()
                    logging.info("Armis Device Connector: Collected %s device data and ingested into sentinel.", len(data))
                    logging.info(
                        "Armis Device Connector: Time taken to post data to Microsoft Sentinel: "
                        f"{(post_end_time - post_start_time):.3f} seconds."
                    )
                    # Delete report from checkpoint table after successful ingestion
                    try:
                        self.checkpoint_table.delete_entity('report', str(report_id))
                        logging.info(f"Removed successfully ingested report {report_id} from checkpoint table")
                    except Exception as err:
                        logging.warning(f"Failed to remove report {report_id} from checkpoint table: {err}")
                except Exception as e:
                    error_msg = f"Failed to ingest data into Sentinel: {e}"
                    self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_SENTINEL_ERROR, error_msg)
                    raise ArmisException(error_msg)
            else:
                logging.info("Armis Device Connector: No device data found in report.")
                raise ArmisDataNotFoundException()

        except ArmisException as err:
            logging.error(err)
            raise ArmisException(f"Armis Device Connector: Error while processing the data. Error: {err}")
        except ArmisTimeOutException:
            raise ArmisTimeOutException()
        except ArmisDataNotFoundException:
            raise ArmisDataNotFoundException()

    def check_data_exists_or_not_device(self):
        """Check_data_exists_or_not is to check if the data is exists or not using the timestamp file.

        Args:
            self: Armis object.

        """
        try:
            self._fetch_device_data()
        except ArmisTimeOutException:
            logging.info(
                "Armis Device Connector: 9:30 mins executed hence stopping the execution"
            )
            return
        except ArmisException as err:
            logging.error(err)
            raise ArmisException(
                "Armis Device Connector: Error occured during checking whether log table exist or not."
            )

        except ArmisDataNotFoundException:
            raise ArmisDataNotFoundException()


class AzureSentinel:
    """AzureSentinel is Used to post data to log analytics."""

    def build_signature(
        self,
        date,
        content_length,
        method,
        content_type,
        resource,
    ):
        """To build the signature."""
        x_headers = "x-ms-date:" + date
        string_to_hash = (
            method
            + "\n"
            + str(content_length)
            + "\n"
            + content_type
            + "\n"
            + x_headers
            + "\n"
            + resource
        )
        bytes_to_hash = bytes(string_to_hash, encoding="utf-8")
        decoded_key = base64.b64decode(shared_key)
        encoded_hash = base64.b64encode(
            hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()
        ).decode()
        authorization = "SharedKey {}:{}".format(customer_id, encoded_hash)
        return authorization

    # Build and send a request to the POST API
    def post_data(self, customer_id, body, log_type):
        """Build and send a request to the POST API."""
        method = "POST"
        content_type = "application/json"
        resource = "/api/logs"
        rfc1123date = datetime.datetime.utcnow().strftime("%a, %d %b %Y %H:%M:%S GMT")
        content_length = len(body)
        try:
            signature = self.build_signature(
                rfc1123date,
                content_length,
                method,
                content_type,
                resource,
            )
        except ArmisException as err:
            logging.error("Armis Device Connector: Error occured: {}".format(err))
            raise ArmisException(
                "Armis Device Connector: Error while generating signature for log analytics."
            )

        uri = (
            "https://"
            + customer_id
            + ".ods.opinsights.azure.com"
            + resource
            + "?api-version=2016-04-01"
        )

        headers = {
            "content-type": content_type,
            "Authorization": signature,
            "Log-Type": log_type,
            "x-ms-date": rfc1123date
        }
        try:
            response = requests.post(uri, data=body, headers=headers)
            if response.status_code >= 200 and response.status_code <= 299:
                logging.info(
                    "Armis Device Connector: Data posted successfully to microsoft sentinel."
                )
            else:
                raise ArmisException(
                    "Armis Device Connector: Response code: {} from posting data to log analytics.".format(
                        response.status_code
                    )
                )

        except ArmisException as err:
            logging.error(err)
            raise ArmisException(
                "Armis Device Connector: Error while posting data to microsoft sentinel."
            )


def main(mytimer: func.TimerRequest) -> None:
    """
    Start the execution.

    Args:
        mytimer (func.TimerRequest): This variable will be used to trigger the function.

    """
    utc_timestamp = (
        datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
    )
    logging.info(
        "Armis Device Connector: Python timer trigger function ran at %s",
        utc_timestamp,
    )

    start_time = time.time()
    armis_obj = ArmisDevice(start_time)

    try:
        armis_obj.check_data_exists_or_not_device()
    except ArmisDataNotFoundException:
        pass

    utc_timestamp_final = (
        datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
    )
    logging.info(
        "Armis Device Connector: execution completed for device at %s.",
        utc_timestamp_final,
    )

    end_time = time.time()
    logging.info(f"Armis Device Connector: Total time taken is {(end_time - start_time):.3f} seconds.")

    if mytimer.past_due:
        logging.info("Armis Device Connector: The timer is past due!")
