"""This function processes failed or unprocessed Armis device reports from the checkpoint table."""

import datetime
import json
import logging
import os
import time

import azure.functions as func

from ..SharedCode.armis_client import ArmisDevice
from ..SharedCode.exports_store import ExportsTableStore
from ..SharedCode.azure_sentinel import AzureSentinel
from Exceptions.ArmisExceptions import (
    ArmisException,
    ArmisTimeOutException,
    ArmisDataNotFoundException
)

# Environment variables
connection_string = os.environ["AzureWebJobsStorage"]
customer_id = os.environ["WorkspaceID"]
armis_devices_table_name = os.environ["ArmisDeviceTableName"]
CHECKPOINT_TABLE_NAME = "ArmisDeviceCheckpoint"

# Status for permanently failed reports
REPORT_STATUS_PERMANENT_FAILURE = "permanent_failure"


def process_unprocessed_reports(armis_obj: ArmisDevice) -> None:
    """Process unprocessed reports from checkpoint table.

    Args:
        armis_obj: ArmisDevice instance to handle report processing

    This function:
    1. Gets unprocessed report IDs from checkpoint table
    2. For each report:
        - Attempts to get S3 URL
        - Downloads and processes report data
        - Ingests into Sentinel
        - Updates status in checkpoint table
    """
    try:
        # Initialize shared modules
        checkpoint_table = ExportsTableStore(connection_string, CHECKPOINT_TABLE_NAME)
        azure_sentinel = AzureSentinel()

        # Get all reports that are not marked as permanent failures
        reports = checkpoint_table.query_by_partition_key('report')
        if not reports:
            logging.info("Armis Device Failed Report Connector: No unprocessed reports found in checkpoint table")
            return

        # Filter out permanently failed reports
        reports = [r for r in reports if r.get('status') != REPORT_STATUS_PERMANENT_FAILURE]
        if not reports:
            logging.info("Armis Device Failed Report Connector: No reports to retry")
            return

        for report in reports:
            report_id = report['RowKey']
            try:
                logging.info(f"Armis Device Failed Report Connector: start processing report with id: '{report_id}'")
                start_time = time.time()

                # Run report
                armis_obj._run_report(report_id)

                # # Get S3 URL for the report
                s3_url = armis_obj.poll_for_report(report_id)

                # # Download and process the report
                data = armis_obj.download_zip_extract_and_parse_csv(report_id, s3_url)

                # # Ingest into Sentinel
                azure_sentinel.post_data(customer_id, json.dumps(data), armis_devices_table_name)
                logging.info(f"Armis Device Failed Report Connector: Successfully ingested report {report_id} into Sentinel")

                # Remove successfully processed report
                checkpoint_table.delete_entity('report', report_id)
                logging.info(f"Armis Device Failed Report Connector: Successfully processed and removed report id '{report_id}' from the checkpoint table")

                end_time = time.time()
                logging.info(f"Armis Device Failed Report Connector: Total time taken to process report '{report_id}' is {(end_time - start_time):.3f} seconds.")
            except ArmisTimeOutException:
                raise
            except (ArmisException, Exception) as e:
                logging.error(f"Armis Device Failed Report Connector: Failed to process report {report_id}: {str(e)}")
                checkpoint_table.merge('report', report_id, {
                    'status': REPORT_STATUS_PERMANENT_FAILURE,
                    'failure_reason': 'processing_error',
                    'error_details': str(e),
                    'last_attempt': datetime.datetime.utcnow().isoformat()
                })
    except ArmisTimeOutException:
        logging.info(
            "Armis Device Failed Report Connector: 9:30 mins executed hence stopping the execution"
        )
        return
    except Exception as e:
        logging.error(f"Armis Device Failed Report Connector: Error while processing unprocessed reports: {str(e)}")
        raise


def main(mytimer: func.TimerRequest) -> None:
    """
    Start the execution.

    Args:
        mytimer (func.TimerRequest): This variable will be used to trigger the function.

    """
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()
    logging.info(
        "Armis Device Failed Report Connector: Python timer trigger function ran at %s",
        utc_timestamp,
    )

    start_time = time.time()
    try:
        armis_obj = ArmisDevice(start_time)
        process_unprocessed_reports(armis_obj)
    except ArmisDataNotFoundException:
        pass
    except Exception as e:
        logging.error(f"Armis Device Failed Report Connector: Error in main function: {str(e)}")
        raise

    end_time = time.time()
    logging.info(f"Armis Device Failed Report Connector: Total time taken is {(end_time - start_time):.3f} seconds.")

    if mytimer.past_due:
        logging.info("Armis Device Failed Report Connector: The timer is past due!")

    logging.info('Python timer trigger function ran at %s', utc_timestamp)
