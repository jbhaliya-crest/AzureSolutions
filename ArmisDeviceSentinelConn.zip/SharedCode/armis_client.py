import csv
import datetime
import io
import json
import logging
import os
import time
import requests
import zipfile

from .exports_store import ExportsTableStore
from .keyvault_secrets_management import KeyVaultSecretManager
from .azure_sentinel import AzureSentinel
from Exceptions.ArmisExceptions import (
    ArmisException,
    ArmisDataNotFoundException,
    ArmisTimeOutException,
)

url = os.environ["ArmisURL"]
API_KEY = os.environ["ArmisSecretKey"]
connection_string = os.environ["AzureWebJobsStorage"]
CHECKPOINT_TABLE_NAME = "ArmisDeviceCheckpoint"
customer_id = os.environ["WorkspaceID"]
armis_devices_table_name = os.environ["ArmisDeviceTableName"]

# Report status constants
REPORT_STATUS_CREATED = "created"
REPORT_STATUS_RUNNING = "running"
REPORT_STATUS_FAILED = "failed"
REPORT_STATUS_TIMEOUT = "timeout"
REPORT_STATUS_SUCCESS = "success"

# Failure reasons
FAILURE_REASON_API_ERROR = "armis_api_error"
FAILURE_REASON_SENTINEL_ERROR = "sentinel_api_error"
FAILURE_REASON_TIMEOUT = "function_timeout"

MAX_RETRY = 5
FUNCTION_APP_TIMEOUT_SECONDS = 570


class ArmisDevice:
    """This class will process the Device data and post it into the Microsoft sentinel."""

    def __init__(self, start_time):
        """__init__ method will initialize object of class."""
        self.start_time = start_time
        self._link = url
        self._header = {}
        self._secret_key = API_KEY
        self.checkpoint_table = None
        self.keyvault_obj = KeyVaultSecretManager()
        self.access_token_key = "armis-access-token"
        self._initialize_checkpoint_table()

    def _initialize_checkpoint_table(self):
        """Initialize the checkpoint table for tracking report status."""
        try:
            self.checkpoint_table = ExportsTableStore(connection_string, CHECKPOINT_TABLE_NAME)
        except Exception as err:
            logging.error(f"Failed to initialize checkpoint table: {err}")
            raise

    def _update_report_status(self, report_id, status, failure_reason=None, error_details=None):
        """Update the status of a report in the checkpoint table.

        Args:
            report_id (str): The ID of the report
            status (str): Current status of the report (created, running, failed, timeout, success)
            failure_reason (str, optional): Reason for failure if status is failed/timeout
            error_details (str, optional): Detailed error message if available
        """
        try:
            entity = {
                'PartitionKey': 'report',
                'RowKey': str(report_id),
                'status': status,
                'failure_reason': failure_reason or '',
                'error_details': error_details or '',
                'timestamp': datetime.datetime.utcnow().isoformat()
            }
            self.checkpoint_table.merge('report', str(report_id), entity)
            logging.info(f"Updated report {report_id} status to {status} in checkpoint table")
        except Exception as err:
            logging.error(f"Failed to update report status in checkpoint table: {err}")

    def _get_failed_reports(self):
        """Get list of reports that failed or timed out and need to be retried.

        Returns:
            list: List of report IDs that need to be retried
        """
        try:
            failed_reports = []
            # Query for failed and timed out reports
            for status in [REPORT_STATUS_FAILED, REPORT_STATUS_TIMEOUT]:
                reports = self.checkpoint_table.query_entities( # to do
                    f"PartitionKey eq 'report' and status eq '{status}'"
                )
                failed_reports.extend(reports)
            return failed_reports
        except Exception as err:
            logging.error(f"Failed to get failed reports from checkpoint table: {err}")
            return []

    def _get_access_token_device(self, armis_link_suffix):
        """
        _get_access_token_device will fetch the access token using api and set it in header for further use.

        Args:
            armis_link_suffix (String): This variable will be suffix/add-on to the link.

        """
        if self._secret_key is not None and self._link is not None:
            body = {"secret_key": self._secret_key}
            try:
                response = requests.post((self._link + armis_link_suffix), data=body)
                if response.status_code == 200:
                    logging.info("Armis Device Connector: Getting access token.")
                    response = response.json()
                    _access_token = response.get("data", {}).get("access_token")
                    self._header.update({"Authorization": _access_token})
                    self.keyvault_obj.set_keyvault_secret(self.access_token_key, _access_token)
                elif response.status_code == 400:
                    raise ArmisException(
                        "Armis Device Connector: Please check either armis URL or armis secret key is wrong."
                    )
                else:
                    raise ArmisException(
                        "Armis Device Connector: Error while generating the access token. Code: {} Message: {}.".format(
                            response.status_code, response.text
                        )
                    )
            except ArmisException as err:
                logging.error(err)
                raise ArmisException(
                    "Armis Device Connector: Error while generating the access token."
                )
        else:
            raise ArmisException(
                "Armis Device Connector: The secret key or link has not been initialized."
            )

    def parse_csv_file_to_python_dict(self, report_id, csv_data):
        """parse_csv_file_to_python_dict will parse the csv file and convert it to python dict."""
        desired_columns = [
            'MAC', 'Category', 'Name', 'Names', 'Model', 'Type', 'Risk', 'First Seen', 'Last Seen',
            'Brand', 'Users', 'Sensor', 'IPv4 Address', 'OS', 'OS Version', 'Tags', 'Location',
            'Boundaries', 'IPv6 Address', 'Site', 'Suspended', 'Tier', 'Alerts', 'Device ID',
            'Visibility', 'Data Sources', 'Access Switch', 'Purdue Level', 'Firmware Version', 'PLC Modules'
        ]

        def to_camel_case(column_name):
            words = column_name.split()
            return ''.join(word.capitalize() for word in words)

        # Process data in memory to efficiently transform CSV rows into Python dictionaries
        parse_start_time = time.time()
        filtered_data = []
        reader = csv.DictReader(io.StringIO(csv_data))
        for row in reader:
            filtered_row = {}
            for col in desired_columns:
                if int(time.time()) >= self.start_time + FUNCTION_APP_TIMEOUT_SECONDS:
                    self._update_report_status(report_id, REPORT_STATUS_TIMEOUT, FAILURE_REASON_TIMEOUT, "Function timeout while parsing CSV file")
                    raise ArmisTimeOutException()
                camel_col = to_camel_case(col)
                filtered_row[camel_col] = row.get(col, None)
            filtered_row['armis_device_time'] = row.get('Last Seen')
            filtered_data.append(filtered_row)

        parse_end_time = time.time()
        logging.info(
            "Armis Device Connector: Time taken to parse CSV data:"
            f"{(parse_end_time - parse_start_time):.3f} seconds."
        )
        return filtered_data

    def get_report_headers(self):
        return {
            'Content-Type': 'application/json',
            'Authorization': self._header.get('Authorization', '')
        }

    def _create_report(self, report_payload) -> int:
        """Create report and return report id"""
        report_id = None
        for attempt in range(MAX_RETRY + 1):
            url = f"{self._link}/reports/"
            logging.info(f"Armis Device Connector: Calling {url} with attempt {attempt + 1}")
            try:
                response = requests.post(url, data=json.dumps(report_payload), headers=self.get_report_headers())
                if response.status_code == 401:
                    logging.info("Armis Device Connector: Token expired. Getting new token.")
                    self._get_access_token_device("/access_token/")
                    continue
                response.raise_for_status()
                report_id = response.json()['data']['id']
                logging.info(f"Armis Device Connector: Report created with id '{report_id}'.")
                self._update_report_status(report_id, REPORT_STATUS_CREATED)
                return report_id
            except requests.exceptions.RequestException as e:
                error_msg = f"Failed to create report: {e}"
                raise ArmisException(error_msg)
            except Exception as e:
                error_msg = f"Unexpected error: {e}"
                raise ArmisException(error_msg)
        else:
            error_msg = "Max retries exceeded while creating report."
            raise ArmisException(error_msg)

    def _run_report(self, report_id):
        run_url = f"{self._link}/reports/{report_id}/_run/"
        self._update_report_status(report_id, REPORT_STATUS_RUNNING)
        for attempt in range(MAX_RETRY + 1):
            try:
                logging.info(f"Armis Device Connector: Calling {run_url} to run the report id {report_id} with attempt {attempt + 1}")
                response = requests.post(run_url, headers=self.get_report_headers())
                if response.status_code == 401:
                    logging.info("Armis Device Connector: Token expired. Getting new token.")
                    self._get_access_token_device("/access_token/")
                    continue
                response.raise_for_status()
                if not response.json().get('success'):
                    error_msg = f"Failed to run report: {response.json()}"
                    self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_API_ERROR, error_msg)
                    raise ArmisException(error_msg)
                break
            except requests.exceptions.RequestException as e:
                error_msg = f"Failed to run report: {e}"
                self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_API_ERROR, error_msg)
                raise ArmisException(error_msg)
            except Exception as e:
                error_msg = f"Unexpected error: {e}"
                self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_API_ERROR, error_msg)
                raise ArmisException(error_msg)
        else:
            error_msg = "Max retries exceeded while running report."
            self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_API_ERROR, error_msg)
            raise ArmisException(error_msg)

    def poll_for_report(self, report_id) -> str:
        """Poll for report readiness every 10 seconds for up to 3 minutes (18 attempts)"""
        s3_url = None
        result_url = f"{self._link}/report-results/{report_id}/"
        logging.info("Armis Device Connector: Starting to poll for report readiness...")
        for attempt in range(18):
            if int(time.time()) >= self.start_time + FUNCTION_APP_TIMEOUT_SECONDS:
                self._update_report_status(report_id, REPORT_STATUS_TIMEOUT, FAILURE_REASON_TIMEOUT, "Function timeout while polling for report")
                raise ArmisTimeOutException()
            try:
                logging.info(f"Armis Device Connector: Calling {result_url} for the report id {report_id} with attempt {attempt + 1}")
                response = requests.get(result_url, headers=self.get_report_headers())
                if response.status_code == 401:
                    logging.info("Armis Device Connector: Token expired. Getting new token.")
                    self._get_access_token_device("/access_token/")
                    continue
                response.raise_for_status()
                data = response.json()
                if data.get('success') and data.get('data', {}).get('url'):
                    s3_url = data['data']['url']
                    self._update_report_status(report_id, REPORT_STATUS_SUCCESS)
                    break
                elif not data.get('success'):
                    logging.info(f"Report not ready yet (attempt {attempt+1}/18): {data.get('message', '')}")
                    time.sleep(10)
                else:
                    error_msg = f"Unexpected response: {data}"
                    self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_API_ERROR, error_msg)
                    raise ArmisException(error_msg)
            except requests.exceptions.HTTPError as e:
                if response.status_code == 404:
                    logging.info(f"Report not ready yet (attempt {attempt+1}/18): 404 Not Found")
                    time.sleep(10)
                    continue
                error_msg = f"Failed to poll report result: {e}"
                self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_API_ERROR, error_msg)
                raise ArmisException(error_msg)
            except requests.exceptions.RequestException as e:
                error_msg = f"Request failed: {e}"
                self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_API_ERROR, error_msg)
                raise ArmisException(error_msg)
            except Exception as e:
                error_msg = f"Unexpected error: {e}"
                self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_API_ERROR, error_msg)
                raise ArmisException(error_msg)
        if not s3_url:
            error_msg = "Report was not ready after 3 minutes."
            self._update_report_status(report_id, REPORT_STATUS_TIMEOUT, FAILURE_REASON_TIMEOUT, error_msg)
            raise ArmisTimeOutException(error_msg)
        return s3_url

    def download_zip_extract_and_parse_csv(self, report_id, s3_url):
        try:
            # Download
            response = requests.get(s3_url)
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            error_msg = f"Error while downloading report: {e}"
            self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_API_ERROR, error_msg)
            raise ArmisException(error_msg)
        except requests.exceptions.RequestException as e:
            error_msg = f"Request failed: {e}"
            self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_API_ERROR, error_msg)
            raise ArmisException(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error: {e}"
            self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_API_ERROR, error_msg)
            raise ArmisException(error_msg)

        # Extract csv file from zip
        csv_data = None
        with zipfile.ZipFile(io.BytesIO(response.content)) as z:
            for file_info in z.infolist():
                if file_info.filename.startswith("Armis Report") and file_info.filename.endswith(".csv"):
                    with z.open(file_info) as csvfile:
                        csv_data = csvfile.read().decode('utf-8', errors="replace")
                        break
        if not csv_data:
            raise ArmisException('No CSV file starting with "Armis Report" found in the ZIP.')

        # filter data from csv and return
        return self.parse_csv_file_to_python_dict(report_id, csv_data)

    def _get_device_data(self, report_payload):
        """Get_device_data is used to get data using api.
        Args:
            report_payload (dict): The payload for the report creation endpoint.
        Returns:
            list: List of device data dicts.
        """
        report_gen_start_time = time.time()

        report_id = self._create_report(report_payload)

        self._run_report(report_id)

        s3_url = self.poll_for_report(report_id)

        data = self.download_zip_extract_and_parse_csv(report_id, s3_url)

        report_gen_end_time = time.time()
        logging.info(f"Armis Device Connector: Time taken from preparing to downloading report: {(report_gen_end_time - report_gen_start_time):.3f} seconds.")

        return report_id, data

    def _fetch_device_data(self):
        """Fetch_device_data is used to push all the data into table."""
        try:
            properties_list = self.keyvault_obj.get_properties_list_of_secrets()

            if self.access_token_key in properties_list:
                self.access_token = self.keyvault_obj.get_keyvault_secret(self.access_token_key)
                self._header.update({"Authorization": self.access_token})
            else:
                self._get_access_token_device("/access_token/")

            report_payload = {
                "asq": "in:devices timeFrame:\"14 Hours\"",
                "emailSubject": "Device Report",
                "reportName": f"DeviceReport-{int(time.time())}",
                "schedule": {
                    "email": ["dummy@dummy.com"],
                    "repeatAmount": "1",
                    "repeatUnit": "days",
                    "reportFileFormat": "csv",
                    "timezone": "Asia/Kolkata"
                },
                "format": "csv"
            }

            report_id, data = self._get_device_data(report_payload)

            azuresentinel = AzureSentinel()
            if data:
                logging.info("Armis Device Connector: Total length of data is %s ", len(data))
                try:
                    # Post data to Microsoft Sentinel
                    post_start_time = time.time()
                    azuresentinel.post_data(customer_id, json.dumps(data), armis_devices_table_name)
                    post_end_time = time.time()
                    logging.info("Armis Device Connector: Collected %s device data and ingested into sentinel.", len(data))
                    logging.info(
                        "Armis Device Connector: Time taken to post data to Microsoft Sentinel: "
                        f"{(post_end_time - post_start_time):.3f} seconds."
                    )
                    # Delete report from checkpoint table after successful ingestion
                    try:
                        self.checkpoint_table.delete_entity('report', str(report_id))
                        logging.info(f"Removed successfully ingested report {report_id} from checkpoint table")
                    except Exception as err:
                        logging.warning(f"Failed to remove report {report_id} from checkpoint table: {err}")
                except Exception as e:
                    error_msg = f"Failed to ingest data into Sentinel: {e}"
                    self._update_report_status(report_id, REPORT_STATUS_FAILED, FAILURE_REASON_SENTINEL_ERROR, error_msg)
                    raise ArmisException(error_msg)
            else:
                logging.info("Armis Device Connector: No device data found in report.")
                raise ArmisDataNotFoundException()

        except ArmisException as err:
            logging.error(err)
            raise ArmisException(f"Armis Device Connector: Error while processing the data. Error: {err}")
        except ArmisTimeOutException:
            raise ArmisTimeOutException()
        except ArmisDataNotFoundException:
            raise ArmisDataNotFoundException()
