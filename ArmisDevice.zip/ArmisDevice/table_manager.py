import logging
from azure.data.tables import TableClient, UpdateMode
from azure.core.exceptions import ResourceNotFoundError, ResourceExistsError, HttpResponseError

from . import constants as constants
from .config import EnvironmentConfig

class TableManager:
    def __init__(self, config: EnvironmentConfig):
        self.table_name = constants.CHECKPOINT_TABLE_NAME
        self.connection_string = config.connection_string
        self.create_table()

    def create_table(self):
        with TableClient.from_connection_string(self.connection_string, self.table_name) as table_client:
            try:
                table_client.create_table()
                logging.info(constants.INFO_LOG.format(f"Table '{self.table_name}' created"))
            except ResourceExistsError:
                logging.warning(constants.INFO_LOG.format(f"Table '{self.table_name}' already exists"))

    def get_entity(self, partition_key: str, row_key: str):
        with TableClient.from_connection_string(self.connection_string, self.table_name) as table_client:
            try:
                entity = table_client.get_entity(partition_key, row_key)
                return entity
            except ResourceNotFoundError:
                logging.info(constants.INFO_LOG.format(f"Entity with partition_key '{partition_key}' and row_key '{row_key}' not found in table '{self.table_name}'"))
                return None

    def delete_entity(self, partition_key: str, row_key: str):
        """
        Delete the record from the table
        """
        with TableClient.from_connection_string(self.connection_string, self.table_name) as table_client:
            try:
                table_client.delete_entity(partition_key, row_key)
                logging.info(constants.INFO_LOG.format(f"Entity with partition_key '{partition_key}' and row_key '{row_key}' deleted from table '{self.table_name}'"))
            except ResourceNotFoundError:
                logging.info(constants.INFO_LOG.format(f"Entity with partition_key '{partition_key}' and row_key '{row_key}' not found in table '{self.table_name}'"))

    def merge_entity(self, partition_key: str, row_key: str, data: dict = None):
        """
        Update the record from the table
        """
        with TableClient.from_connection_string(self.connection_string, self.table_name) as table_client:
            try:
                entity = {
                    "PartitionKey": partition_key,
                    "RowKey": row_key,
                }
                if data is not None:
                    entity.update(data)
                table_client.upsert_entity(mode=UpdateMode.MERGE, entity=entity)
                logging.info(constants.INFO_LOG.format(f"Entity with partition_key '{partition_key}' and row_key '{row_key}' updated in table '{self.table_name}' with enity '{entity}'"))
            except Exception as e:
                logging.error(constants.INFO_LOG.format(f"Error while updating entity in table '{self.table_name}': {e}"))
                raise e
