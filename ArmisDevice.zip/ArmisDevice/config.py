import os

class EnvironmentConfig:
    def __init__(self):
        self.load_environment()

    def load_environment(self):
        self.armis_secret_key = os.environ.get("ArmisSecretKey")
        self.armis_url = os.environ.get("ArmisURL")
        self.connection_string = os.environ.get("AzureWebJobsStorage")
        self.customer_id = os.environ.get("WorkspaceID")
        self.shared_key = os.environ.get("WorkspaceKey")
        self.armis_devices_table_name = os.environ.get("ArmisDeviceTableName")