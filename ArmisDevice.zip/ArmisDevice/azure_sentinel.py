import requests
import datetime
import hashlib
import hmac
import base64
import logging

from . import constants as constants

from .config import EnvironmentConfig
from .errors import ArmisException

class AzureSentinel:
    def __init__(self, config: EnvironmentConfig):
        self.customer_id = config.customer_id
        self.shared_key = config.shared_key
        self.log_type = config.armis_devices_table_name
        self.uri = f"https://{self.customer_id}.ods.opinsights.azure.com/api/logs?api-version=2016-04-01"

    def build_signature(self, date, content_length, method, content_type, resource):
        x_headers = 'x-ms-date:' + date
        string_to_hash = method + "\n" + str(content_length) + "\n" + content_type + "\n" + x_headers + "\n" + resource
        bytes_to_hash = bytes(string_to_hash, encoding="utf-8")
        decoded_key = base64.b64decode(self.shared_key)
        encoded_hash = base64.b64encode(hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()).decode()
        return f"SharedKey {self.customer_id}:{encoded_hash}"

    def post_data(self, body):
        method = 'POST'
        content_type = 'application/json'
        resource = '/api/logs'
        rfc1123date = datetime.datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
        content_length = len(body)
        signature = self.build_signature(rfc1123date, content_length, method, content_type, resource)

        headers = {
            'content-type': content_type,
            'Authorization': signature,
            'Log-Type': self.log_type,
            'x-ms-date': rfc1123date
        }
        try:
            response = requests.post(self.uri, data=body, headers=headers)
            if (response.status_code >= 200 and response.status_code <= 299):
                logging.info(
                    constants.INFO_LOG.format("Data posted successfully to log analytics workspace.")
                )
            else:
                raise ArmisException(
                    "Response code: {} while posting data to log analytics workspace.".format(
                        response.status_code
                    )
                )
        except ArmisException as err:
            logging.error(constants.INFO_LOG.format(err))
            raise ArmisException("Error while posting data to log analytics workspace.")
