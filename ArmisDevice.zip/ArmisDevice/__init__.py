import datetime
import json
import logging
import time

from . import constants as constants
from . import utils as utils

from .armis_client import ArmisClient
from .azure_sentinel import AzureSentinel
from .config import EnvironmentConfig
from .table_manager import TableManager
from .errors import ConfigurationError, ArmisTimeOutException, ArmisDataNotFoundException

import azure.functions as func # type: ignore


def validate_required_fields(config: EnvironmentConfig):
    for field in constants.REQUIRED_FIELDS:
        if getattr(config, field) is None:
            err_message = f"Error: {field} is required."
            logging.error(constants.INFO_LOG.format(err_message))
            raise ConfigurationError(err_message)
    logging.info(
        constants.INFO_LOG.format("All required fields are available.")
    )


def collect_and_ingest_data(start_time, armis_client: ArmisClient, table_manager: TableManager, azure_sentinel: AzureSentinel):
    try:
        checkpoint = table_manager.get_entity(
            partition_key=constants.PARTITION_KEY,
            row_key=constants.RAW_KEY
        )

        params = constants.PARAMS

        if checkpoint is None:
            logging.info(constants.INFO_LOG.format("Checkpoint does't exist."))
            params.update({
                "aql": "in:devices"
            })
        else:
            logging.info(constants.INFO_LOG.format(f"Found the checkpoint with data: {checkpoint}"))
            # To Do: handle only offset in checkpoint
            params.update({
                "aql": f"in:devices after:{checkpoint.get("last_seen")}",
                "from": checkpoint.get("offset")
            })

        while True:
            if int(time.time()) >= (start_time + constants.FUNCTION_APP_TIMEOUT_SECONDS):
                raise ArmisTimeOutException()
            (devices, total, next, count) = armis_client.get(endpoint=constants.API_ENDPOINT, params=params)
            logging.info(f"count, next, total : {count}, {next}, {total}")

            if count == 0:
                err_message = "No data found to ingest."
                logging.info(constants.INFO_LOG.format(err_message))
                raise ArmisDataNotFoundException(err_message)
            
            azure_sentinel.post_data(body=json.dumps(devices))
            logging.info(f"{count} events ingested successfully.")
            last_seen = devices[-1]["lastSeen"][:19]
            last_seen = utils.validate_timestamp(last_seen)

            if next is None:
                data = {
                    "last_seen": last_seen,
                    "offset": 0,
                }
                table_manager.merge_entity(
                    partition_key=constants.PARTITION_KEY,
                    row_key=constants.RAW_KEY,
                    data=data,
                )
                break

            data = {"offset": next}
            table_manager.merge_entity(
                partition_key=constants.PARTITION_KEY,
                row_key=constants.RAW_KEY,
                data=data,
            )
            params.update({
                "from": next
            })
    except ArmisDataNotFoundException as ex:
        return
    except ArmisTimeOutException as ex:
        logging.info(
            constants.INFO_LOG.format("function ran for 9.5 mins. Hence stopping the execution.")
        )
        return
        

def main(mytimer: func.TimerRequest) -> None:
    """
    Start the execution.

    Args:
        mytimer (func.TimerRequest): This variable will be used to trigger the function.

    """
    func_start_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()
    logging.info(
        constants.INFO_LOG.format(f"Python timer trigger function ran at {func_start_timestamp}")
    )

    start_time = time.time()

    config = EnvironmentConfig()
    validate_required_fields(config)

    armis_client = ArmisClient(config=config)
    table_manager = TableManager(config=config)
    azure_sentinel = AzureSentinel(config=config)

    collect_and_ingest_data(start_time, armis_client, table_manager, azure_sentinel)

    func_end_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()
    logging.info(
        constants.INFO_LOG.format(f"Python timer trigger function completed at {func_end_timestamp}")
    )

    end_time = time.time()
    logging.info(
        constants.INFO_LOG.format(f"Total time taken: {(end_time - start_time):.3f} seconds.")
    )

    if mytimer.past_due:
        logging.info('The timer is past due!')
