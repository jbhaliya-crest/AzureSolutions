# Azure function maximum runtime
FUNCTION_APP_TIMEOUT_SECONDS = 570

INFO_LOG = "Armis Device Connector: {}"

CHECKPOINT_TABLE_NAME = "ArmisDeviceCheckpoint"

# Required input fields
REQUIRED_FIELDS = [
    "armis_secret_key",
    "armis_url",
    "connection_string",
    "customer_id",
    "shared_key",
    "armis_devices_table_name",
]

# Table keys
PARTITION_KEY = "armisdevice"
RAW_KEY = "devicecheckpoint"

# Pagination size
LIMIT = 1000

# Rest API param
PARAMS= {
    "aql": {},
    "from": 0,
    "length": LIMIT,
    "orderBy": "lastSeen",
}

# Rest api maximum retry limit
MAX_RETRY = 5

# URL constants
API_ENDPOINT = "/search/"