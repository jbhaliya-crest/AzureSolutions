import requests
import logging

from time import time

from . import constants as constants
from .config import EnvironmentConfig
from .errors import ArmisException, ArmisDataNotFoundException, ArmisTimeOutException, ConfigurationError


class ArmisClient:
    def __init__(self, config: EnvironmentConfig):
        """
        Initialize an instance of ArmisClient.

        Args:
            start_time (time): The start time of the client instance.
            config (EnvironmentConfig): The configuration object containing the Armis URL and secret key.
        """
        self.url = config.armis_url
        self.secret_key = config.armis_secret_key
        self.header = {}
        self.get_token()

    def get_token(self):
        """
        Get the access token for the Armis API.

        This method retrieves the access token needed to make API calls to the Armis API.

        Raises:
            ArmisException: If there is an error while retrieving the access token.
        """
        try:
            body = {
                "secret_key": self.secret_key
            }
            response = requests.post((self.url + "/access_token/"), data=body)

            if response.status_code == 200:
                response = response.json()
                access_token = response.get("data", {}).get("access_token")
                self.header.update({"Authorization": access_token})
                logging.info(constants.INFO_LOG.format("Access token generated."))
            elif response.status_code == 400:
                err_message = "Please check either 'armis_url' or 'armis_secret_key' is wrong."
                logging.error(
                    constants.INFO_LOG.format(err_message)
                )
                raise ArmisException(err_message)
            else:
                err_message = "Error while generating the access token. Code: {} Message: {}.".format(
                    response.status_code, response.text
                )
                logging.error(
                    constants.INFO_LOG.format(err_message)
                )
                raise ArmisException(err_message)
        except ArmisException as ex:
            raise
        except Exception as ex:
            raise

    def reterive_data(self, result: dict):
        """
        Retrieve data from the API response.

        Args:
            result (dict): The API response.

        Returns:
            tuple: A tuple containing the devices, total count, next offset and count.
        """
        devices = result.get('data').get('results')
        total = result.get('data').get('total')
        next = result.get('data').get('next')
        count = result.get('data').get('count')
        return (devices, total, next, count)

    def get(self, endpoint: str, params: dict):
        try:
            for i in range(constants.MAX_RETRY + 1):
                response = requests.get(
                    url= self.url + endpoint,
                    params= params,
                    headers= self.header,
                )

                if response.status_code == 200:
                    response = response.json()
                    return self.reterive_data(response)
                elif response.status_code == 400:
                    err_message = "Bad request. Missing aql parameter."
                    logging.error(constants.INFO_LOG.format(err_message))
                    raise ArmisException(err_message)
                elif response.status_code == 401:
                    logging.error(constants.INFO_LOG.format("Authorization information is missing or invalid."))
                    logging.info(constants.INFO_LOG.format(f"Retry number: {str(i + 1)}"))
                    self.get_token()
                    continue
                else:
                    err_message = f"Error while fetching data. status Code:{response.status_code} error message:{response.text}."
                    logging.error(constants.INFO_LOG.format(err_message))
                    raise ArmisException(err_message)
            err_message = "Max retry exceeded."
            logging.error(constants.INFO_LOG.format(err_message))
            raise ArmisException(err_message)
        except ArmisException:
            raise
        except requests.exceptions.ConnectionError:
            err_message = "Connection error while getting data from device api."
            logging.error(constants.INFO_LOG.format(err_message))
            raise
        except requests.exceptions.RequestException:
            err_message = "Request error while getting data from device api."
            logging.error(constants.INFO_LOG.format(err_message))
            raise
