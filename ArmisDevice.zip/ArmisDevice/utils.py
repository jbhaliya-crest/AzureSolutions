import logging
from . import constants as constants
from .errors import ArmisException

def validate_timestamp(last_seen:str):
    """function is used to validate the timestamp format. The timestamp should be in
    ISO 8601 format 'YYYY-MM-DDTHH:MM:SS'. If the timestamp is not in correct format, it will
    be formatted according to the given timestamp format.

    Args:
        last_seen (String): Timestamp string to be validated.

    Returns:
        String: Validated timestamp string.
    """
    try:
        if len(last_seen) != 19:
            if len(last_seen) == 10:
                last_seen += "T00:00:00"
                logging.info(
                    "Armis Device Connector: 'T:00:00:00' added as only date is available."
                )
            else:
                splited_time = last_seen.split("T")
                if len(splited_time[1]) == 5:
                    splited_time[1] += ":00"
                    logging.info(
                        "Armis Device Connector: ':00' added as seconds not available."
                    )
                elif len(splited_time[1]) == 2:
                    splited_time[1] += ":00:00"
                    logging.info(
                        "Armis Device Connector: ':00:00' added as only hour is available."
                    )
                last_seen = "T".join(splited_time)
        return last_seen
    except Exception as err:
        logging.error(constants.INFO_LOG.format(f"Error occurred while validating the timestamp. Error: {err}"))
        raise ArmisException(err)