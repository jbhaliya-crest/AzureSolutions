"""Module with constants and configurations for the Cyware CTIX integration."""

import os

# *Logging related constants
LOG_LEVEL = os.environ.get("LogLevel", "INFO")
LOGS_STARTS_WITH = "CywareCTIX"
LOG_FORMAT = "{}(method = {}) : {} : {}"
FUNCTION_NAME = "CywareCTIXAPISentinelConnector"
CONNECTOR_VERSION = "1.0.0"
# User-Agent sent on every API call: "cyware/intel-exchange (microsoft-sentinel/<version>)"
USER_AGENT = "cyware/intel-exchange (microsoft-sentinel/{})".format(CONNECTOR_VERSION)

# *Sentinel Upload Indicator API related constants
CLIENT_ID = os.environ.get("CLIENT_ID", "")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET", "")
TENANT_ID = os.environ.get("TENANT_ID", "")
WORKSPACE_ID = os.environ.get("WORKSPACE_ID", "")
# Azure cloud of the workspace; the ARM template sets it from environment().name. Empty means AzureCloud.
AZURE_CLOUD = os.environ.get("AZURE_CLOUD", "").strip() or "AzureCloud"
# Microsoft Entra authority, token scope and Upload API host per Azure cloud
AZURE_CLOUD_ENDPOINTS = {
    "AzureCloud": {
        "authority": "https://login.microsoftonline.com/{}",
        "scope": "https://management.azure.com/.default",
        "upload_host": "https://api.ti.sentinel.azure.com",
    },
    "AzureUSGovernment": {
        "authority": "https://login.microsoftonline.us/{}",
        "scope": "https://management.usgovcloudapi.net/.default",
        "upload_host": "https://api.ti.sentinel.azure.us",
    },
}
_CLOUD_ENDPOINTS = AZURE_CLOUD_ENDPOINTS.get(AZURE_CLOUD, AZURE_CLOUD_ENDPOINTS["AzureCloud"])
AUTHORITY_URL = _CLOUD_ENDPOINTS["authority"]
AUTH_SCOPE = [_CLOUD_ENDPOINTS["scope"]]
UPLOAD_INDICATOR_URL = (
    _CLOUD_ENDPOINTS["upload_host"]
    + "/workspaces/{}/threat-intelligence-stix-objects:upload?api-version=2024-02-01-preview"
)
STIX_SOURCE_SYSTEM = "CywareCTIX"
STIX_BATCH_SIZE = 100

# *Cyware CTIX API related constants
CTIX_BASE_URL = os.environ.get("CTIX_BASE_URL", "").strip().rstrip("/")
CTIX_ACCESS_ID = os.environ.get("CTIX_ACCESS_ID", "").strip()
CTIX_SECRET_KEY = os.environ.get("CTIX_SECRET_KEY", "").strip()
CTIX_SAVED_RESULT_SET_LABEL = os.environ.get("CTIX_SAVED_RESULT_SET_LABEL", "")
CTIX_SAVED_RESULT_SET_ENDPOINT = "/ingestion/rules/save_result_set/"
CTIX_SAVED_RESULT_SET_VERSION = "v3"
CTIX_SIGNATURE_VALIDITY_SECONDS = 25
# The Saved Result Set API can lag behind the publish time of a record, so a window ends this many seconds
# before the run time; records published in the last seconds are collected by the next run.
CTIX_API_LAG_SECONDS = 60
# Days to look back on the first run, same as the Splunk app: any whole number of days (0 or more);
# an empty or invalid value uses the default.
CTIX_LOOKBACK_DAYS = os.environ.get("CTIX_LOOKBACK_DAYS", "").strip()
CTIX_LOOKBACK_DAYS_DEFAULT = 30
CTIX_PAGE_SIZE = 100
# Page size used to fetch all records published in one second together
CTIX_MAX_PAGE_SIZE = 1000

# *Cyware CTIX enrichment (Bulk IOC Lookup) API related constants
CTIX_FETCH_ENRICHED_DATA = os.environ.get("CTIX_FETCH_ENRICHED_DATA", "true").strip().lower() == "true"
CTIX_BULK_LOOKUP_ENDPOINT = "/ingestion/openapi/bulk-lookup/indicator/"
CTIX_BULK_LOOKUP_BATCH_SIZE = 100
# Comma-separated without spaces: CTIX ignores field names that contain spaces. 'id' is required to match results.
CTIX_ENRICHMENT_FIELDS = (
    "id,name,custom_attributes,description,enrichment_data,first_seen,last_seen,"
    "published_collections,relations,sub_type,manual_review"
)
# Relation types kept for the workbook; CTIX returns up to the latest 100 relations per indicator.
CTIX_RELATION_TYPES = ["threat-actor", "attack-pattern", "malware", "campaign", "tool", "report"]

# *Checkpoint related constants
CONN_STRING = os.environ.get("AzureWebJobsStorage", "")
CHECKPOINT_TABLE_NAME = "CywareCTIXCheckpoint"
CHECKPOINT_PARTITION_KEY = "SavedResultSet"

# *Error Messages for Exception
REQUEST_ERROR_MSG = "Request error : Error-{}"
CONNECTION_ERROR_MSG = "Connection error : Error-{}"
JSON_DECODE_ERROR_MSG = "JSONDecode error : Error-{}"
TIME_OUT_ERROR_MSG = "Timeout error : Error-{}"
MAX_RETRY_ERROR_MSG = "Max retries exceeded : {} Last exception: {}"

# *Retry and Timeout Configuration
MAX_RETRIES = 3
RETRY_BACKOFF_SECONDS = [10, 20, 30]
RETRY_STATUS_CODES = [429, 500, 502, 503, 504]
SENTINEL_429_SLEEP = 60
REQUEST_TIMEOUT = 60
FUNCTION_APP_TIMEOUT_SECONDS = 570

# *STIX indicator related constants
STIX_SPEC_VERSION = "2.1"
SUPPORTED_SDO_TYPE = "indicator"
# Saved Result Set (v3) flags; an indicator with any of them set to true is not ingested
EXCLUDED_STATUS_FLAGS = ("is_revoked", "is_whitelist", "is_deprecated", "is_false_positive")
# Indicator name shown in the Microsoft Sentinel Threat intelligence page: "Cyware CTIX - <IOC type> - <value>"
STIX_INDICATOR_NAME_FORMAT = "Cyware CTIX - {} - {}"
# STIX indicator-type-ov values derived from CTIX status flags
INDICATOR_TYPE_BENIGN = "benign"
INDICATOR_TYPE_MALICIOUS = "malicious-activity"

# CTIX indicator_type.type -> STIX cyber-observable object type. The pattern is built from indicator_type
# (type and attribute_field), e.g. mutex/name -> "[mutex:name = '...']".
SUPPORTED_OBSERVABLE_TYPES = [
    "ipv4-addr",
    "ipv6-addr",
    "domain-name",
    "url",
    "email-addr",
    "file",
    "mac-addr",
    "mutex",
    "user-account",
    "directory",
    "process",
    "email-message",
    "network-traffic",
    "x509-certificate",
    "windows-registry-key",
    "autonomous-system",
    "software",
    "artifact",
]
# CTIX YARA indicators are sent as a YARA pattern (pattern_type "yara") instead of a STIX pattern.
YARA_IOC_TYPE = "yara"
# STIX artifact properties that can hold the value of a CTIX artifact indicator.
ARTIFACT_PATTERN_PROPERTIES = ("url", "payload_bin", "mime_type")
# Hex length of a hash value -> STIX hash algorithm, used when CTIX does not name the algorithm of an artifact.
HASH_LENGTH_ALGORITHMS = {32: "MD5", 40: "SHA-1", 64: "SHA-256", 128: "SHA-512"}
# STIX properties with integer values; their pattern value is not quoted, e.g. "[autonomous-system:number = 64512]"
INTEGER_PATTERN_PROPERTIES = {
    ("autonomous-system", "number"),
    ("network-traffic", "src_port"),
    ("network-traffic", "dst_port"),
}
# STIX file/artifact hash property: the CTIX attribute_field prefix and the pattern path format, e.g. hashes.'SHA-256'
HASHES_PREFIX = "hashes."
HASH_PATH_FORMAT = "hashes.'{}'"
# IOC type name used for file name indicators (indicator_type {"type": "file", "attribute_field": "name"})
FILE_NAME_IOC_TYPE = "file-name"

# Days added to valid_from (or to the current time when valid_from is empty) to set the indicator valid_until
VALID_UNTIL_DAYS = 180

# CTIX hash algorithm (file indicator_type.attribute_field, e.g. "SHA-256") -> STIX hash algorithm name
HASH_ALGORITHMS = {
    "MD5": "MD5",
    "SHA-1": "SHA-1",
    "SHA1": "SHA-1",
    "SHA-224": "SHA-224",
    "SHA-256": "SHA-256",
    "SHA256": "SHA-256",
    "SHA-384": "SHA-384",
    "SHA-512": "SHA-512",
    "SHA512": "SHA-512",
    "SHA3-224": "SHA3-224",
    "SHA3-256": "SHA3-256",
    "SHA3-384": "SHA3-384",
    "SHA3-512": "SHA3-512",
    "SSDEEP": "SSDEEP",
}

# CTIX TLP -> STIX 2.1 TLP marking definition
TLP_MARKING_DEFINITIONS = {
    "CLEAR": "marking-definition--613f2e26-407d-48c7-9eca-b8e91df99dc9",
    "WHITE": "marking-definition--613f2e26-407d-48c7-9eca-b8e91df99dc9",
    "GREEN": "marking-definition--34098fce-860f-48ae-8e50-ebd3cc5e41da",
    "AMBER": "marking-definition--f88d31f6-486f-44da-b317-01333bde0b82",
    "AMBER+STRICT": "marking-definition--f88d31f6-486f-44da-b317-01333bde0b82",
    "RED": "marking-definition--5e57c739-391a-4eb3-b6be-7d15ca92d5ed",
}
