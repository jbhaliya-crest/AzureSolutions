"""This module contains the Cyware CTIX API client for the Saved Result Set API."""

import base64
import hashlib
import hmac
import inspect
import json
import re
import time
import requests
from SharedCode import consts
from SharedCode.logger import applogger
from SharedCode.utils import ensure_time_left
from SharedCode.cyware_ctix_exceptions import (
    CywareCTIXAPIException,
    CywareCTIXAuthenticationException,
)


class CywareCTIXClient:
    """Client for the Cyware CTIX Saved Result Set API.

    Every request is signed with a fresh HMAC-SHA256 signature, because a CTIX signature is only
    valid for a few seconds after it is generated.
    """

    def __init__(self, deadline=None):
        """Initialize the client with the CTIX server URL and Open API credentials.

        Args:
            deadline (float|None): Unix time by which the function must stop; requests and retry waits that
                could run past it are not started.
        """
        self.deadline = deadline
        self.base_url = consts.CTIX_SERVER_URL
        self.access_id = consts.CTIX_ACCESS_ID
        self.secret_key = consts.CTIX_SECRET_KEY
        self.log_format = consts.LOG_FORMAT
        self.session = requests.Session()
        self.session.headers["User-Agent"] = consts.USER_AGENT

    def _get_auth_params(self):
        """Generate the CTIX authentication query parameters for one request.

        Returns:
            dict: AccessID, Expires and Signature query parameters. The signature is
                Base64(HMAC-SHA256(SecretKey, AccessID + newline + Expires)); requests URL-encodes it.
        """
        expires = int(time.time()) + consts.CTIX_SIGNATURE_VALIDITY_SECONDS
        to_sign = "{}\n{}".format(self.access_id, expires)
        digest = hmac.new(self.secret_key.encode("utf-8"), to_sign.encode("utf-8"), hashlib.sha256).digest()
        return {
            "AccessID": self.access_id,
            "Expires": expires,
            "Signature": base64.b64encode(digest).decode("utf-8"),
        }

    @staticmethod
    def _hide_query_string(error):
        """Remove URL query strings from an error message so the authentication parameters are not logged.

        Args:
            error (Exception): Request exception whose message may contain the request URL.

        Returns:
            str: Error message with every query string replaced by '?***'.
        """
        return re.sub(r"\?[^\s'\"]+", "?***", str(error))

    @staticmethod
    def _get_error_detail(response):
        """Extract a readable error detail from a CTIX error response.

        CTIX returns errors in several formats: 'errors.server' (title, support code, message),
        'errors.client' ({"<type>": {title, message}}), a 'details' string, or an HTML page. The HTTP
        status is logged by the caller, and 'txn_id' is added because Cyware support needs it to trace a request.

        Args:
            response (requests.Response): CTIX API response.

        Returns:
            str: Readable error detail.
        """
        try:
            body = response.json()
        except ValueError:
            body = None
        if isinstance(body, dict):
            errors = body.get("errors") or {}
            server_error = errors.get("server") if isinstance(errors, dict) else None
            client_error = errors.get("client") if isinstance(errors, dict) else None
            if isinstance(client_error, dict) and not {"title", "message"} & set(client_error):
                client_error = next((value for value in client_error.values() if isinstance(value, dict)), None)
            detail = None
            if isinstance(server_error, dict) and server_error:
                detail = "{} ({}): {}".format(
                    server_error.get("title"), server_error.get("support_code"), server_error.get("message")
                )
            elif isinstance(client_error, dict) and client_error:
                detail = "{}: {}".format(client_error.get("title"), client_error.get("message"))
            elif body.get("details") or body.get("detail"):
                detail = str(body.get("details") or body.get("detail"))
                # Django REST framework wraps messages as [ErrorDetail(string="...", code='...')].
                messages = re.findall(r"ErrorDetail\(string=(?:\"(.*?)\"|'(.*?)'), code=", detail)
                if messages:
                    detail = "; ".join(double or single for double, single in messages)
            if detail:
                txn_id = body.get("txn_id") or (client_error or {}).get("txn_id")
                return "{} (txn_id: {})".format(detail, txn_id) if txn_id else detail
            return json.dumps(body)[:500]
        # Non-JSON responses (e.g. an HTML 404 page): keep the text only.
        text = re.sub(r"(?is)<head.*?</head>", " ", response.text or "")
        text = re.sub(r"<[^>]+>", " ", text)
        return re.sub(r"\s+", " ", text).strip()[:200]

    def _get(self, endpoint, params):
        """Make a signed GET request to CTIX with retry and backoff.

        Args:
            endpoint (str): CTIX API endpoint path.
            params (dict): Query parameters other than authentication.

        Returns:
            dict: JSON response.
        """
        return self._request("GET", endpoint, params)

    def _post(self, endpoint, params, body):
        """Make a signed POST request to CTIX with retry and backoff.

        Args:
            endpoint (str): CTIX API endpoint path.
            params (dict): Query parameters other than authentication.
            body (dict): JSON request body.

        Returns:
            dict: JSON response.
        """
        return self._request("POST", endpoint, params, body)

    def _request(self, method, endpoint, params, body=None):
        """Make a signed request to CTIX with retry and backoff.

        Retries connection errors, timeouts, expired signatures and retryable status codes,
        waiting 10s/20s/30s between attempts.

        Args:
            method (str): HTTP method, GET or POST.
            endpoint (str): CTIX API endpoint path.
            params (dict): Query parameters other than authentication.
            body (dict): JSON request body for POST requests.

        Returns:
            dict: JSON response.

        Raises:
            CywareCTIXAuthenticationException: If the CTIX credentials are invalid.
            CywareCTIXAPIException: If the request fails after all retries or returns a non-retryable error.
            CywareCTIXTimeoutException: If the request or retry wait could run past the execution limit.
        """
        __method_name = inspect.currentframe().f_code.co_name
        url = "{}{}".format(self.base_url, endpoint)
        last_error = None
        for attempt in range(1, consts.MAX_RETRIES + 1):
            ensure_time_left(self.deadline, consts.REQUEST_TIMEOUT)
            try:
                request_params = dict(params)
                request_params.update(self._get_auth_params())
                response = self.session.request(
                    method=method,
                    url=url,
                    params=request_params,
                    json=body,
                    timeout=consts.REQUEST_TIMEOUT,
                    allow_redirects=False,
                )
                if response.status_code == 200:
                    return response.json()
                error_detail = self._get_error_detail(response)
                if response.status_code == 401:
                    applogger.error(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.FUNCTION_NAME,
                            "CTIX authentication failed (401): {}. Verify the CTIX Access ID and Secret Key.".format(
                                error_detail
                            ),
                        )
                    )
                    raise CywareCTIXAuthenticationException("CTIX authentication failed (401): {}".format(error_detail))
                if response.status_code in (301, 302, 307, 308):
                    raise CywareCTIXAPIException(
                        "CTIX returned a redirect ({}). Verify the CTIX Server URL format, e.g. "
                        "https://yourtenant.cyware.com/ctixapi".format(response.status_code)
                    )
                if response.status_code == 404:
                    error_detail = error_detail.rstrip(". ") + ". Verify the CTIX Server URL ends with /ctixapi"
                expired_signature = response.status_code == 400 and "TokenExpired" in response.text
                if response.status_code not in consts.RETRY_STATUS_CODES and not expired_signature:
                    applogger.error(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.FUNCTION_NAME,
                            "CTIX request failed with status {}: {}".format(response.status_code, error_detail),
                        )
                    )
                    raise CywareCTIXAPIException(
                        "CTIX request failed with status {}: {}".format(response.status_code, error_detail)
                    )
                last_error = "status {}: {}".format(response.status_code, error_detail)
            except (CywareCTIXAuthenticationException, CywareCTIXAPIException):
                raise
            except requests.exceptions.Timeout as error:
                last_error = consts.TIME_OUT_ERROR_MSG.format(self._hide_query_string(error))
            except requests.exceptions.ConnectionError as error:
                last_error = consts.CONNECTION_ERROR_MSG.format(self._hide_query_string(error))
            except requests.exceptions.RequestException as error:
                last_error = consts.REQUEST_ERROR_MSG.format(self._hide_query_string(error))
            except json.JSONDecodeError as error:
                last_error = consts.JSON_DECODE_ERROR_MSG.format(error)

            if attempt < consts.MAX_RETRIES:
                sleep_time = consts.RETRY_BACKOFF_SECONDS[min(attempt - 1, len(consts.RETRY_BACKOFF_SECONDS) - 1)]
                ensure_time_left(self.deadline, sleep_time + consts.REQUEST_TIMEOUT)
                applogger.warning(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.FUNCTION_NAME,
                        "CTIX request attempt {}/{} failed ({}). Retrying in {} seconds.".format(
                            attempt, consts.MAX_RETRIES, last_error, sleep_time
                        ),
                    )
                )
                time.sleep(sleep_time)

        applogger.error(
            self.log_format.format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.FUNCTION_NAME,
                consts.MAX_RETRY_ERROR_MSG.format(consts.MAX_RETRIES, last_error),
            )
        )
        raise CywareCTIXAPIException(consts.MAX_RETRY_ERROR_MSG.format(consts.MAX_RETRIES, last_error))

    def get_saved_result_set_page(self, label, from_timestamp, to_timestamp, page, page_size=None):
        """Get one page of Saved Result Set (v3) records for a label and time window.

        Args:
            label (str): Saved Result Set label of the CTIX rule (exact, case-sensitive).
            from_timestamp (int): Start of the window, publish time in epoch seconds (inclusive).
            to_timestamp (int): End of the window, publish time in epoch seconds (inclusive).
            page (int): Page number, starting at 1.
            page_size (int): Records per page (default CTIX_PAGE_SIZE).

        Returns:
            tuple: (list of records, bool indicating whether a next page exists, total record count).
        """
        params = {
            "version": consts.CTIX_SAVED_RESULT_SET_VERSION,
            "label_name": label,
            "from_timestamp": from_timestamp,
            "to_timestamp": to_timestamp,
            "page": page,
            "page_size": page_size or consts.CTIX_PAGE_SIZE,
        }
        response = self._get(consts.CTIX_SAVED_RESULT_SET_ENDPOINT, params)
        return response.get("results") or [], bool(response.get("next")), response.get("total", 0)

    def bulk_lookup_indicators(self, object_ids):
        """Get the enrichment fields of indicators with the Bulk IOC Lookup (Advanced) API.

        Looks indicators up by CTIX object id (max 100 per call) with their latest enrichment data and
        relations. The response is paginated, so every page is collected.

        Args:
            object_ids (list): CTIX indicator object ids (max 100).

        Returns:
            dict: Lookup result per CTIX object id. Ids that CTIX does not return are absent.
        """
        results = {}
        page = 1
        while True:
            params = {
                "enrichment_data": "true",
                "relation_data": "true",
                "fields": consts.CTIX_ENRICHMENT_FIELDS,
                "page": page,
                "page_size": consts.CTIX_BULK_LOOKUP_BATCH_SIZE,
            }
            response = self._post(consts.CTIX_BULK_LOOKUP_ENDPOINT, params, {"object_id": list(object_ids)})
            for item in response.get("results") or []:
                if item.get("id"):
                    results[item["id"]] = item
            if not response.get("next"):
                return results
            page += 1
