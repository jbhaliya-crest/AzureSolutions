"""This module contains the Cyware CTIX API client for the Saved Result Set API."""

import base64
import hashlib
import hmac
import inspect
import json
import time
import requests
from SharedCode import consts
from SharedCode.logger import applogger
from SharedCode.cyware_ctix_exceptions import (
    CywareCTIXAPIException,
    CywareCTIXAuthenticationException,
)


class CywareCTIXClient:
    """Client for the Cyware CTIX Saved Result Set API.

    Every request is signed with a fresh HMAC-SHA1 signature, because a CTIX signature is only
    valid for a few seconds after it is generated.
    """

    def __init__(self):
        """Initialize the client with the CTIX server URL and Open API credentials."""
        self.base_url = consts.CTIX_SERVER_URL
        self.access_id = consts.CTIX_ACCESS_ID
        self.secret_key = consts.CTIX_SECRET_KEY
        self.log_format = consts.LOG_FORMAT
        self.session = requests.Session()

    def _get_auth_params(self):
        """Generate the CTIX authentication query parameters for one request.

        Returns:
            dict: AccessID, Expires and Signature query parameters. The signature is
                Base64(HMAC-SHA1(SecretKey, AccessID + "\\n" + Expires)); requests URL-encodes it.
        """
        expires = int(time.time()) + consts.CTIX_SIGNATURE_VALIDITY_SECONDS
        to_sign = "{}\n{}".format(self.access_id, expires)
        digest = hmac.new(self.secret_key.encode("utf-8"), to_sign.encode("utf-8"), hashlib.sha1).digest()
        return {
            "AccessID": self.access_id,
            "Expires": expires,
            "Signature": base64.b64encode(digest).decode("utf-8"),
        }

    @staticmethod
    def _get_error_detail(response):
        """Extract the CTIX error title, support code and message from an error response.

        Args:
            response (requests.Response): CTIX API response.

        Returns:
            str: Readable error detail.
        """
        try:
            server_error = (response.json().get("errors") or {}).get("server") or {}
            if server_error:
                return "{} ({}): {}".format(
                    server_error.get("title"), server_error.get("support_code"), server_error.get("message")
                )
        except (ValueError, AttributeError):
            pass
        return response.text[:500]

    def _get(self, endpoint, params):
        """Make a signed GET request to CTIX with retry and backoff.

        Args:
            endpoint (str): CTIX API endpoint path.
            params (dict): Query parameters other than authentication.

        Returns:
            dict: JSON response.
        """
        return self._request("GET", endpoint, params)

    def _post(self, endpoint, params, body):
        """Make a signed POST request to CTIX with retry and backoff.

        Args:
            endpoint (str): CTIX API endpoint path.
            params (dict): Query parameters other than authentication.
            body (dict): JSON request body.

        Returns:
            dict: JSON response.
        """
        return self._request("POST", endpoint, params, body)

    def _request(self, method, endpoint, params, body=None):
        """Make a signed request to CTIX with retry and backoff.

        Retries connection errors, timeouts, expired signatures and retryable status codes,
        waiting 10s/20s/30s between attempts.

        Args:
            method (str): HTTP method, GET or POST.
            endpoint (str): CTIX API endpoint path.
            params (dict): Query parameters other than authentication.
            body (dict): JSON request body for POST requests.

        Returns:
            dict: JSON response.

        Raises:
            CywareCTIXAuthenticationException: If the CTIX credentials are invalid.
            CywareCTIXAPIException: If the request fails after all retries or returns a non-retryable error.
        """
        __method_name = inspect.currentframe().f_code.co_name
        url = "{}{}".format(self.base_url, endpoint)
        last_error = None
        for attempt in range(1, consts.MAX_RETRIES + 1):
            try:
                request_params = dict(params)
                request_params.update(self._get_auth_params())
                response = self.session.request(
                    method=method,
                    url=url,
                    params=request_params,
                    json=body,
                    timeout=consts.REQUEST_TIMEOUT,
                    allow_redirects=False,
                )
                if response.status_code == 200:
                    return response.json()
                error_detail = self._get_error_detail(response)
                if response.status_code == 401:
                    applogger.error(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.FUNCTION_NAME,
                            "CTIX authentication failed (401): {}. Verify the CTIX Access ID and Secret Key.".format(
                                error_detail
                            ),
                        )
                    )
                    raise CywareCTIXAuthenticationException("CTIX authentication failed (401): {}".format(error_detail))
                if response.status_code in (301, 302, 307, 308):
                    raise CywareCTIXAPIException(
                        "CTIX returned a redirect ({}). Verify the CTIX Server URL has no trailing slash "
                        "and ends with '/ctixapi'.".format(response.status_code)
                    )
                expired_signature = response.status_code == 400 and "TokenExpired" in response.text
                if response.status_code not in consts.RETRY_STATUS_CODES and not expired_signature:
                    applogger.error(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.FUNCTION_NAME,
                            "CTIX request failed with status {}: {}".format(response.status_code, error_detail),
                        )
                    )
                    raise CywareCTIXAPIException(
                        "CTIX request failed with status {}: {}".format(response.status_code, error_detail)
                    )
                last_error = "status {}: {}".format(response.status_code, error_detail)
            except (CywareCTIXAuthenticationException, CywareCTIXAPIException):
                raise
            except requests.exceptions.Timeout as error:
                last_error = consts.TIME_OUT_ERROR_MSG.format(error)
            except requests.exceptions.ConnectionError as error:
                last_error = consts.CONNECTION_ERROR_MSG.format(error)
            except requests.exceptions.RequestException as error:
                last_error = consts.REQUEST_ERROR_MSG.format(error)
            except json.JSONDecodeError as error:
                last_error = consts.JSON_DECODE_ERROR_MSG.format(error)

            if attempt < consts.MAX_RETRIES:
                sleep_time = consts.RETRY_BACKOFF_SECONDS[min(attempt - 1, len(consts.RETRY_BACKOFF_SECONDS) - 1)]
                applogger.warning(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.FUNCTION_NAME,
                        "CTIX request attempt {}/{} failed ({}). Retrying in {} seconds.".format(
                            attempt, consts.MAX_RETRIES, last_error, sleep_time
                        ),
                    )
                )
                time.sleep(sleep_time)

        applogger.error(
            self.log_format.format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.FUNCTION_NAME,
                consts.MAX_RETRY_ERROR_MSG.format(consts.MAX_RETRIES, last_error),
            )
        )
        raise CywareCTIXAPIException(consts.MAX_RETRY_ERROR_MSG.format(consts.MAX_RETRIES, last_error))

    def get_saved_result_set_page(self, label, from_timestamp, to_timestamp, page):
        """Get one page of Saved Result Set (v3) records for a label and time window.

        Args:
            label (str): Saved Result Set label of the CTIX rule (exact, case-sensitive).
            from_timestamp (int): Start of the window, publish time in epoch seconds (inclusive).
            to_timestamp (int): End of the window, publish time in epoch seconds.
            page (int): Page number, starting at 1.

        Returns:
            tuple: (list of records, bool indicating whether a next page exists, total record count).
        """
        params = {
            "version": consts.CTIX_SAVED_RESULT_SET_VERSION,
            "label_name": label,
            "from_timestamp": from_timestamp,
            "to_timestamp": to_timestamp,
            "page": page,
            "page_size": consts.CTIX_PAGE_SIZE,
        }
        response = self._get(consts.CTIX_SAVED_RESULT_SET_ENDPOINT, params)
        return response.get("results") or [], bool(response.get("next")), response.get("total", 0)

    def bulk_lookup_indicators(self, object_ids):
        """Get the enrichment fields of indicators with the Bulk IOC Lookup (Advanced) API.

        Looks indicators up by CTIX object id (max 100 per call) with their latest enrichment data and
        relations. The response is paginated, so every page is collected.

        Args:
            object_ids (list): CTIX indicator object ids (max 100).

        Returns:
            dict: Lookup result per CTIX object id. Ids that CTIX does not return are absent.
        """
        results = {}
        page = 1
        while True:
            params = {
                "enrichment_data": "true",
                "relation_data": "true",
                "fields": consts.CTIX_ENRICHMENT_FIELDS,
                "page": page,
                "page_size": consts.CTIX_BULK_LOOKUP_BATCH_SIZE,
            }
            response = self._post(consts.CTIX_BULK_LOOKUP_ENDPOINT, params, {"object_id": list(object_ids)})
            for item in response.get("results") or []:
                if item.get("id"):
                    results[item["id"]] = item
            if not response.get("next"):
                return results
            page += 1
