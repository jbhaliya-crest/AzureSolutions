"""This file contains custom Exception classes for Cyware CTIX connector."""


class CywareCTIXException(Exception):
    """Exception class to handle general Cyware CTIX connector exceptions."""

    def __init__(self, message=None) -> None:
        """Initialize custom Cyware CTIX exception with custom message."""
        super().__init__(message)


class CywareCTIXTimeoutException(Exception):
    """Exception class to handle the function approaching its execution time limit."""

    def __init__(self, message=None) -> None:
        """Initialize custom Cyware CTIX timeout exception with custom message."""
        super().__init__(message)


class CywareCTIXAuthenticationException(Exception):
    """Exception class to handle Cyware CTIX authentication (HMAC signature) failures."""

    def __init__(self, message=None) -> None:
        """Initialize custom Cyware CTIX authentication exception with custom message."""
        super().__init__(message)


class CywareCTIXAPIException(Exception):
    """Exception class to handle Cyware CTIX API call failures."""

    def __init__(self, message=None) -> None:
        """Initialize custom Cyware CTIX API exception with custom message."""
        super().__init__(message)


class SentinelAuthenticationException(Exception):
    """Exception class to handle Microsoft Entra ID token generation failures."""

    def __init__(self, message=None) -> None:
        """Initialize custom Sentinel authentication exception with custom message."""
        super().__init__(message)


class SentinelUploadException(Exception):
    """Exception class to handle Microsoft Sentinel Upload Indicator API failures."""

    def __init__(self, message=None) -> None:
        """Initialize custom Sentinel upload exception with custom message."""
        super().__init__(message)
