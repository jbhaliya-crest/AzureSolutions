"""Module with constants and configurations for the Cyware CTIX integration."""

import os

# *Logging related constants
LOG_LEVEL = os.environ.get("LogLevel", "INFO")
LOGS_STARTS_WITH = "CywareCTIX"
LOG_FORMAT = "{}(method = {}) : {} : {}"
FUNCTION_NAME = "CywareCTIXAPISentinelConnector"

# *Sentinel Upload Indicator API related constants
CLIENT_ID = os.environ.get("CLIENT_ID", "")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET", "")
TENANT_ID = os.environ.get("TENANT_ID", "")
WORKSPACE_ID = os.environ.get("WORKSPACE_ID", "")
AUTHORITY_URL = "https://login.microsoftonline.com/{}"
AUTH_SCOPE = ["https://management.azure.com/.default"]
UPLOAD_INDICATOR_URL = (
    "https://api.ti.sentinel.azure.com/workspaces/{}/"
    "threat-intelligence-stix-objects:upload?api-version=2024-02-01-preview"
)
STIX_SOURCE_SYSTEM = "CywareCTIX"
STIX_BATCH_SIZE = 100

# *Cyware CTIX API related constants
CTIX_SERVER_URL = os.environ.get("CTIX_SERVER_URL", "").strip().rstrip("/")
CTIX_ACCESS_ID = os.environ.get("CTIX_ACCESS_ID", "").strip()
CTIX_SECRET_KEY = os.environ.get("CTIX_SECRET_KEY", "").strip()
CTIX_SAVED_RESULT_SET_LABEL = os.environ.get("CTIX_SAVED_RESULT_SET_LABEL", "")
CTIX_SAVED_RESULT_SET_ENDPOINT = "/ingestion/rules/save_result_set/"
CTIX_SAVED_RESULT_SET_VERSION = "v3"
CTIX_SIGNATURE_VALIDITY_SECONDS = 20
CTIX_LOOKBACK_MINUTES = int(os.environ.get("CTIX_LOOKBACK_MINUTES", "1440"))
CTIX_PAGE_SIZE = int(os.environ.get("CTIX_PAGE_SIZE", "200"))

# *Cyware CTIX enrichment (Bulk IOC Lookup) API related constants
CTIX_FETCH_ENRICHED_DATA = os.environ.get("CTIX_FETCH_ENRICHED_DATA", "true").strip().lower() == "true"
CTIX_BULK_LOOKUP_ENDPOINT = "/ingestion/openapi/bulk-lookup/indicator/"
CTIX_BULK_LOOKUP_BATCH_SIZE = 100
# Comma-separated without spaces: CTIX ignores field names that contain spaces. 'id' is required to match results.
CTIX_ENRICHMENT_FIELDS = (
    "id,name,custom_attributes,description,enrichment_data,first_seen,last_seen,"
    "published_collections,relations,sub_type,manual_review"
)
# Relation types kept for the workbook; CTIX returns up to the latest 100 relations per indicator.
CTIX_RELATION_TYPES = ["threat-actor", "attack-pattern", "malware", "campaign", "tool", "report"]
# Only a summary of each enrichment result is stored; raw tool responses can exceed 250 KB.
CTIX_ENRICHMENT_SUMMARY_KEYS = ["tool", "verdict", "enriched_on"]

# *Checkpoint related constants
CONN_STRING = os.environ.get("AzureWebJobsStorage", "")
CHECKPOINT_TABLE_NAME = "CywareCTIXCheckpoint"
CHECKPOINT_PARTITION_KEY = "SavedResultSet"

# *Error Messages for Exception
UNEXPECTED_ERROR_MSG = "Unexpected error : Error-{}"
HTTP_ERROR_MSG = "HTTP error : Error-{}"
REQUEST_ERROR_MSG = "Request error : Error-{}"
CONNECTION_ERROR_MSG = "Connection error : Error-{}"
JSON_DECODE_ERROR_MSG = "JSONDecode error : Error-{}"
TIME_OUT_ERROR_MSG = "Timeout error : Error-{}"
MAX_RETRY_ERROR_MSG = "Max retries exceeded : {} Last exception: {}"

# *Retry and Timeout Configuration
MAX_RETRIES = int(os.environ.get("CTIX_MAX_RETRIES", "3"))
RETRY_BACKOFF_SECONDS = [10, 20, 30]
RETRY_STATUS_CODES = [429, 500, 502, 503, 504]
SENTINEL_429_SLEEP = 60
REQUEST_TIMEOUT = 60
FUNCTION_APP_TIMEOUT_SECONDS = 570

# *STIX indicator related constants
STIX_SPEC_VERSION = "2.1"
CYWARE_IDENTITY_ID = "identity--3e2aab8c-1d84-5a1e-9d36-1c8f41d0b4e9"
# STIX extension that carries the CTIX fields used by the workbook (stored in ThreatIntelIndicators.Data.extensions)
CTIX_EXTENSION_ID = "extension-definition--8f3a6c1e-2b7d-5e94-a0c3-6d1f4e2b9a75"
SUPPORTED_SDO_TYPE = "indicator"
# STIX indicator-type-ov values derived from CTIX status flags
INDICATOR_TYPE_BENIGN = "benign"
INDICATOR_TYPE_MALICIOUS = "malicious-activity"

# CTIX indicator_type.type -> STIX cyber-observable object type
SUPPORTED_OBSERVABLE_TYPES = ["ipv4-addr", "ipv6-addr", "domain-name", "url", "email-addr", "file"]

# CTIX hash ioc_type -> STIX hash algorithm name
HASH_ALGORITHMS = {
    "MD5": "MD5",
    "SHA-1": "SHA-1",
    "SHA1": "SHA-1",
    "SHA-224": "SHA-224",
    "SHA-256": "SHA-256",
    "SHA256": "SHA-256",
    "SHA-384": "SHA-384",
    "SHA-512": "SHA-512",
    "SHA512": "SHA-512",
    "SHA3-224": "SHA3-224",
    "SHA3-256": "SHA3-256",
    "SHA3-384": "SHA3-384",
    "SHA3-512": "SHA3-512",
    "SSDEEP": "SSDEEP",
}

# CTIX TLP -> STIX 2.1 TLP marking definition
TLP_MARKING_DEFINITIONS = {
    "CLEAR": "marking-definition--613f2e26-407d-48c7-9eca-b8e91df99dc9",
    "WHITE": "marking-definition--613f2e26-407d-48c7-9eca-b8e91df99dc9",
    "GREEN": "marking-definition--34098fce-860f-48ae-8e50-ebd3cc5e41da",
    "AMBER": "marking-definition--f88d31f6-486f-44da-b317-01333bde0b82",
    "AMBER+STRICT": "marking-definition--f88d31f6-486f-44da-b317-01333bde0b82",
    "RED": "marking-definition--5e57c739-391a-4eb3-b6be-7d15ca92d5ed",
}
