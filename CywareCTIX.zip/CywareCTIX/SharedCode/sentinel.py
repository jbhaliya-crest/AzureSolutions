"""This module contains the Microsoft Sentinel client for the Upload Indicators API."""

import inspect
import json
import re
import time
import msal
import requests
from SharedCode import consts
from SharedCode.logger import applogger
from SharedCode.cyware_ctix_exceptions import (
    SentinelAuthenticationException,
    SentinelUploadException,
)


class MicrosoftSentinel:
    """Microsoft Sentinel client for the STIX Objects Upload API.

    Uses an MSAL confidential client, which caches the access token and refreshes it before it
    expires, so long runs never use an expired token.
    """

    def __init__(self):
        """Initialize the MSAL client and validate the Microsoft Entra ID credentials."""
        self.log_format = consts.LOG_FORMAT
        self.upload_url = consts.UPLOAD_INDICATOR_URL.format(consts.WORKSPACE_ID)
        self.msal_app = self._build_msal_app()
        self.get_access_token()

    @staticmethod
    def _build_msal_app():
        """Build the MSAL confidential client application.

        Returns:
            msal.ConfidentialClientApplication: MSAL client with an empty token cache.
        """
        return msal.ConfidentialClientApplication(
            client_id=consts.CLIENT_ID,
            client_credential=consts.CLIENT_SECRET,
            authority=consts.AUTHORITY_URL.format(consts.TENANT_ID),
        )

    def get_access_token(self, force_refresh=False):
        """Get a Microsoft Entra ID access token for the Upload Indicators API.

        Args:
            force_refresh (bool): Ignore the cached token and request a new one.

        Returns:
            str: Bearer access token.

        Raises:
            SentinelAuthenticationException: If the token cannot be acquired.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            if force_refresh:
                self.msal_app = self._build_msal_app()
            result = self.msal_app.acquire_token_for_client(scopes=consts.AUTH_SCOPE)
        except (ValueError, requests.exceptions.RequestException) as error:
            raise SentinelAuthenticationException(
                "Error acquiring Microsoft Entra ID token: {}".format(error)
            ) from error
        if "access_token" not in result:
            error_message = "{}: {}".format(result.get("error"), result.get("error_description"))
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.FUNCTION_NAME,
                    "Microsoft Entra ID authentication failed. Verify the Tenant ID, Client ID and Client "
                    "Secret: {}".format(error_message),
                )
            )
            raise SentinelAuthenticationException("Microsoft Entra ID authentication failed: {}".format(error_message))
        return result["access_token"]

    def upload_indicators(self, stix_objects):
        """Upload STIX indicators to Microsoft Sentinel in batches of 100.

        Args:
            stix_objects (list): STIX 2.1 indicator objects.

        Returns:
            dict: 'success_count' and 'failure_count' of the uploaded indicators.

        Raises:
            SentinelUploadException: If a batch cannot be uploaded after retries.
        """
        success_count = 0
        failure_count = 0
        for start in range(0, len(stix_objects), consts.STIX_BATCH_SIZE):
            batch = stix_objects[start:start + consts.STIX_BATCH_SIZE]
            failed = self._upload_batch(batch)
            success_count += len(batch) - failed
            failure_count += failed
        return {"success_count": success_count, "failure_count": failure_count}

    def _log_validation_errors(self, batch, response_json):
        """Log per-indicator validation errors returned by the Upload Indicators API.

        Args:
            batch (list): Uploaded batch of STIX indicators.
            response_json (dict): API response with an 'errors' array.

        Returns:
            int: Number of indicators that failed validation.
        """
        __method_name = inspect.currentframe().f_code.co_name
        failed_indexes = set()
        for error in response_json.get("errors") or []:
            index = error.get("recordIndex")
            if isinstance(index, int) and 0 <= index < len(batch):
                failed_indexes.add(index)
                applogger.warning(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.FUNCTION_NAME,
                        "Indicator '{}' ({}) skipped, failed validation: {}".format(
                            batch[index].get("name"), batch[index].get("id"), error.get("errorMessages")
                        ),
                    )
                )
        return len(failed_indexes) if failed_indexes else len(response_json.get("errors") or [])

    @staticmethod
    def _get_retry_after(response):
        """Get the wait time of a throttled (429) response.

        Args:
            response (requests.Response): Upload Indicators API response.

        Returns:
            int: Seconds to wait before retrying.
        """
        retry_after = response.headers.get("Retry-After")
        if retry_after and retry_after.isdigit():
            return int(retry_after)
        match = re.search(r"(\d+) seconds", response.text or "")
        return int(match.group(1)) if match else consts.SENTINEL_429_SLEEP

    def _upload_batch(self, batch):
        """Upload one batch (max 100) of STIX indicators.

        Args:
            batch (list): STIX indicator objects.

        Returns:
            int: Number of indicators in the batch that failed validation.

        Raises:
            SentinelUploadException: If the batch cannot be uploaded after retries.
        """
        __method_name = inspect.currentframe().f_code.co_name
        body = json.dumps({"sourcesystem": consts.STIX_SOURCE_SYSTEM, "stixobjects": batch})
        token_refreshed = False
        last_error = None
        attempt = 0
        while attempt < consts.MAX_RETRIES:
            attempt += 1
            try:
                headers = {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer {}".format(self.get_access_token()),
                }
                response = requests.post(
                    url=self.upload_url, headers=headers, data=body, timeout=consts.REQUEST_TIMEOUT
                )
            except requests.exceptions.RequestException as error:
                last_error = consts.REQUEST_ERROR_MSG.format(error)
                time.sleep(consts.RETRY_BACKOFF_SECONDS[min(attempt - 1, len(consts.RETRY_BACKOFF_SECONDS) - 1)])
                continue

            if 200 <= response.status_code <= 299:
                try:
                    response_json = response.json() if response.text else {}
                except ValueError:
                    response_json = {}
                failed = self._log_validation_errors(batch, response_json) if response_json.get("errors") else 0
                applogger.info(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.FUNCTION_NAME,
                        "Uploaded batch of {} indicators ({} failed validation).".format(len(batch), failed),
                    )
                )
                return failed
            if response.status_code == 400:
                if "Workspace" in response.text and "valid" in response.text:
                    raise SentinelUploadException("Invalid Workspace ID: {}".format(response.text[:500]))
                try:
                    return self._log_validation_errors(batch, response.json())
                except ValueError:
                    raise SentinelUploadException("Upload rejected (400): {}".format(response.text[:500]))
            if response.status_code in (401, 403):
                if not token_refreshed:
                    token_refreshed = True
                    attempt -= 1
                    self.get_access_token(force_refresh=True)
                    continue
                applogger.error(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.FUNCTION_NAME,
                        "Upload unauthorized ({}). Verify that the App Registration has the Microsoft Sentinel "
                        "Contributor role on the workspace.".format(response.status_code),
                    )
                )
                raise SentinelUploadException(
                    "Upload unauthorized ({}): check the Microsoft Sentinel Contributor role assignment.".format(
                        response.status_code
                    )
                )
            if response.status_code == 404:
                raise SentinelUploadException("Workspace '{}' not found (404).".format(consts.WORKSPACE_ID))
            if response.status_code in consts.RETRY_STATUS_CODES:
                sleep_time = (
                    self._get_retry_after(response)
                    if response.status_code == 429
                    else consts.RETRY_BACKOFF_SECONDS[min(attempt - 1, len(consts.RETRY_BACKOFF_SECONDS) - 1)]
                )
                last_error = "status {}: {}".format(response.status_code, response.text[:300])
                applogger.warning(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.FUNCTION_NAME,
                        "Upload attempt {}/{} failed ({}). Retrying in {} seconds.".format(
                            attempt, consts.MAX_RETRIES, last_error, sleep_time
                        ),
                    )
                )
                time.sleep(sleep_time)
                continue
            raise SentinelUploadException(
                "Upload failed with status {}: {}".format(response.status_code, response.text[:500])
            )
        raise SentinelUploadException(consts.MAX_RETRY_ERROR_MSG.format(consts.MAX_RETRIES, last_error))
