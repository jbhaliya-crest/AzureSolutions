"""This module manages the ingestion checkpoint in Azure Table Storage."""

import inspect
from azure.core.exceptions import ResourceExistsError, ResourceNotFoundError
from azure.data.tables import TableServiceClient, UpdateMode
from SharedCode import consts
from SharedCode.logger import applogger


class StateManager:
    """Read and write the per-label ingestion checkpoint in Azure Table Storage.

    Each Saved Result Set label has its own checkpoint entity (RowKey = label), so labels can be
    added or removed without affecting the progress of the others.
    """

    def __init__(self, connection_string, table_name):
        """Initialize the table client and create the checkpoint table on first use.

        Args:
            connection_string (str): Azure Storage connection string.
            table_name (str): Name of the checkpoint table.
        """
        service_client = TableServiceClient.from_connection_string(conn_str=connection_string)
        try:
            service_client.create_table(table_name=table_name)
        except ResourceExistsError:
            pass
        self.table_client = service_client.get_table_client(table_name=table_name)

    @staticmethod
    def _row_key(label):
        """Build a Table Storage safe RowKey from a label.

        Args:
            label (str): Saved Result Set label.

        Returns:
            str: RowKey without characters that Table Storage does not allow.
        """
        return "".join("_" if char in "/\\#?" or ord(char) < 32 else char for char in label)

    def get(self, label):
        """Get the checkpoint of a label.

        Args:
            label (str): Saved Result Set label.

        Returns:
            dict: Checkpoint with 'from_timestamp', 'to_timestamp' and 'page', or None on first run.
        """
        try:
            entity = self.table_client.get_entity(
                partition_key=consts.CHECKPOINT_PARTITION_KEY, row_key=self._row_key(label)
            )
            return {
                "from_timestamp": int(entity["from_timestamp"]),
                "to_timestamp": int(entity["to_timestamp"]) if entity.get("to_timestamp") else None,
                "page": int(entity.get("page", 1)),
            }
        except ResourceNotFoundError:
            return None

    def post(self, label, from_timestamp, to_timestamp, page):
        """Save the checkpoint of a label.

        Args:
            label (str): Saved Result Set label.
            from_timestamp (int): Start of the window still to be processed (epoch seconds).
            to_timestamp (int|None): End of an unfinished window, or None when the window is complete.
            page (int): Next page to fetch within the unfinished window.
        """
        __method_name = inspect.currentframe().f_code.co_name
        entity = {
            "PartitionKey": consts.CHECKPOINT_PARTITION_KEY,
            "RowKey": self._row_key(label),
            "label": label,
            "from_timestamp": int(from_timestamp),
            "to_timestamp": int(to_timestamp) if to_timestamp else 0,
            "page": int(page),
        }
        self.table_client.upsert_entity(entity=entity, mode=UpdateMode.REPLACE)
        applogger.info(
            consts.LOG_FORMAT.format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.FUNCTION_NAME,
                "Checkpoint saved for label '{}': {}".format(label, entity),
            )
        )
