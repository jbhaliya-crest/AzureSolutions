"""This module maps Cyware CTIX Saved Result Set (v3) objects to STIX 2.1 indicators."""

import json
import uuid
from datetime import datetime, timezone
from SharedCode import consts


class UnsupportedIndicatorException(Exception):
    """Raised when a CTIX object cannot be converted into a STIX indicator."""


def _to_stix_timestamp(epoch_value):
    """Convert an epoch timestamp (seconds, may contain fractions) to a STIX timestamp.

    Args:
        epoch_value (int|float|None): Epoch seconds.

    Returns:
        str: ISO 8601 UTC timestamp with millisecond precision and 'Z' suffix, or None.
    """
    if epoch_value in (None, ""):
        return None
    try:
        timestamp = datetime.fromtimestamp(float(epoch_value), tz=timezone.utc)
    except (TypeError, ValueError, OverflowError, OSError):
        return None
    return timestamp.strftime("%Y-%m-%dT%H:%M:%S.") + "{:03d}Z".format(timestamp.microsecond // 1000)


def _escape_pattern_value(value):
    """Escape a value for use inside a single-quoted STIX pattern string.

    Args:
        value (str): Raw observable value.

    Returns:
        str: Value with backslashes and single quotes escaped.
    """
    return value.replace("\\", "\\\\").replace("'", "\\'")


def _get_ioc_type(ctix_object):
    """Get the IOC type of a CTIX indicator; for files the hash algorithm (e.g. SHA-256).

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.

    Returns:
        str: IOC type.
    """
    indicator_type = ctix_object.get("indicator_type") or {}
    observable_type = str(indicator_type.get("type") or ctix_object.get("ioc_type") or "").strip()
    if observable_type == "file":
        attribute_field = str(indicator_type.get("attribute_field") or "")
        algorithm = attribute_field.replace("hashes.", "").strip("'\" ")
        return algorithm or str(ctix_object.get("ioc_type") or observable_type)
    return observable_type


def _build_pattern(ctix_object):
    """Build the STIX pattern of a CTIX indicator.

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.

    Returns:
        str: STIX pattern, e.g. "[ipv4-addr:value = '1.2.3.4']".

    Raises:
        UnsupportedIndicatorException: If the indicator type cannot be mapped to a STIX pattern.
    """
    value = str(ctix_object.get("name") or ctix_object.get("sdo_name") or "").strip()
    if not value:
        raise UnsupportedIndicatorException("indicator has no value")
    indicator_type = ctix_object.get("indicator_type") or {}
    observable_type = (indicator_type.get("type") or ctix_object.get("ioc_type") or "").strip()
    attribute_field = (indicator_type.get("attribute_field") or "value").strip()
    ioc_type = str(ctix_object.get("ioc_type") or "").strip()

    if observable_type == "file" or ioc_type.upper() in consts.HASH_ALGORITHMS:
        if attribute_field.startswith("hashes."):
            path = attribute_field
        else:
            algorithm = consts.HASH_ALGORITHMS.get(ioc_type.upper())
            if not algorithm:
                raise UnsupportedIndicatorException("unsupported file hash type '{}'".format(ioc_type))
            path = "hashes.'{}'".format(algorithm)
        return "[file:{} = '{}']".format(path, _escape_pattern_value(value))

    if observable_type not in consts.SUPPORTED_OBSERVABLE_TYPES:
        raise UnsupportedIndicatorException(
            "indicator type '{}' is not mapped to a STIX pattern".format(observable_type)
        )
    return "[{}:{} = '{}']".format(observable_type, attribute_field, _escape_pattern_value(value))


def _get_names(values):
    """Get the names from a CTIX tag value (a list of strings or objects, null, or {"name": [...]}).

    Args:
        values (list|dict|None): CTIX tags.

    Returns:
        list: Unique, non-empty names in original order.
    """
    if isinstance(values, dict):
        values = values.get("name") or []
    if not isinstance(values, list):
        return []
    names = []
    for value in values:
        name = value.get("name") if isinstance(value, dict) else value
        if name and str(name).strip():
            names.append(str(name).strip())
    return list(dict.fromkeys(names))


def _get_relations(ctix_object, enrichment):
    """Get the related object names per relation type used by the workbook.

    The Bulk IOC Lookup API returns relations as {"<type>": ["<name>", ...]}; Saved Result Set objects can
    carry relationship objects with source/target types and names. Both are merged.

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.
        enrichment (dict): Bulk IOC Lookup result of the indicator, or None.

    Returns:
        dict: Relation type -> list of related object names, for the types in CTIX_RELATION_TYPES.
    """
    relations = {relation_type: [] for relation_type in consts.CTIX_RELATION_TYPES}
    lookup_relations = (enrichment or {}).get("relations")
    if isinstance(lookup_relations, dict):
        for relation_type, names in lookup_relations.items():
            if relation_type in relations:
                relations[relation_type].extend(_get_names(names))
    for relation in ctix_object.get("relations") or []:
        if not isinstance(relation, dict):
            continue
        for side in ("target", "source"):
            relation_type = relation.get("{}_type".format(side))
            name = relation.get("{}_name".format(side))
            if relation_type in relations and name and name != ctix_object.get("name"):
                relations[relation_type].append(str(name))
    return {relation_type: list(dict.fromkeys(names)) for relation_type, names in relations.items()}


def _parse_json_value(value):
    """Parse a JSON-encoded string value, returning the original value if it is not JSON.

    Args:
        value: Value that may be a JSON object or array encoded as a string.

    Returns:
        The decoded value, or the original value.
    """
    if isinstance(value, str) and value.strip()[:1] in ("{", "["):
        try:
            return json.loads(value)
        except ValueError:
            return value
    return value


def _get_custom_attributes(ctix_object, enrichment):
    """Get the custom attributes of an indicator as a list of name/value pairs.

    The Bulk IOC Lookup API returns 'custom_attribute_name'/'custom_attribute_value' (values can be
    JSON-encoded strings); Saved Result Set objects use 'name'/'value'. The lookup result is preferred.

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.
        enrichment (dict): Bulk IOC Lookup result of the indicator, or None.

    Returns:
        list: [{"name": ..., "value": ...}].
    """
    attributes = (enrichment or {}).get("custom_attributes") or ctix_object.get("custom_attributes") or []
    if not isinstance(attributes, list):
        return []
    result = []
    for attribute in attributes:
        if not isinstance(attribute, dict):
            continue
        name = attribute.get("custom_attribute_name", attribute.get("name"))
        value = attribute.get("custom_attribute_value", attribute.get("value"))
        if name:
            result.append({"name": str(name), "value": _parse_json_value(value)})
    return result


def _get_enrichment_summary(enrichment):
    """Get a summary of the enrichment results of an indicator.

    Only the summary keys are kept; raw tool responses are never stored because a single response can
    exceed the size limits of a Log Analytics field.

    Args:
        enrichment (dict): Bulk IOC Lookup result of the indicator, or None.

    Returns:
        list: One summary object per enrichment tool.
    """
    summary = []
    for item in (enrichment or {}).get("enrichment_data") or []:
        if not isinstance(item, dict):
            continue
        entry = {key: item[key] for key in consts.CTIX_ENRICHMENT_SUMMARY_KEYS if item.get(key) not in (None, "")}
        if entry:
            summary.append(entry)
    return summary


def _get_confidence(ctix_object):
    """Get the STIX confidence of a CTIX object (analyst score overrides the CTIX score).

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.

    Returns:
        int: Confidence between 0 and 100, or None when CTIX has no score.
    """
    for key in ("analyst_score", "ctix_score"):
        score = _get_score(ctix_object.get(key))
        if score is not None:
            return score
    return None


def _get_score(value):
    """Convert a CTIX score to an integer between 0 and 100.

    Args:
        value: CTIX score (number, numeric string, "NA" or None).

    Returns:
        int: Score, or None when the value is empty or not a number.
    """
    if value in (None, ""):
        return None
    try:
        return max(0, min(100, int(round(float(value)))))
    except (TypeError, ValueError):
        return None


def _get_tlp(ctix_object):
    """Get the current TLP of a CTIX object (analyst TLP, else CTIX TLP, else source TLP).

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.

    Returns:
        str: TLP in upper case, or None when CTIX has no TLP.
    """
    for key in ("analyst_tlp", "ctix_tlp", "source_tlp"):
        tlp = str(ctix_object.get(key) or "").strip().upper()
        if tlp and tlp != "NONE":
            return tlp
    return None


def _get_stix_id(ctix_object):
    """Get the STIX id of an indicator, reusing the CTIX object id when it is a UUID.

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.

    Returns:
        str: STIX indicator id.
    """
    ctix_id = str(ctix_object.get("id") or "")
    try:
        return "indicator--{}".format(uuid.UUID(ctix_id))
    except ValueError:
        value = "{}|{}".format(ctix_object.get("ioc_type"), ctix_object.get("name"))
        return "indicator--{}".format(uuid.uuid5(uuid.NAMESPACE_URL, value))


def _build_extension(ctix_object, record_tags, enrichment, relations):
    """Build the CTIX property extension with the fields used by the Cyware CTIX workbook.

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.
        record_tags (list): Tag names of the Saved Result Set record.
        enrichment (dict): Bulk IOC Lookup result of the indicator, or None.
        relations (dict): Relation type -> related object names.

    Returns:
        dict: STIX 'extensions' property.
    """
    lookup = enrichment or {}
    extension = {
        "extension_type": "property-extension",
        "ctix_id": str(ctix_object.get("id")),
        "ioc_type": _get_ioc_type(ctix_object),
        "ctix_score": _get_score(ctix_object.get("ctix_score")),
        "tlp": _get_tlp(ctix_object),
        "ctix_created": _to_stix_timestamp(ctix_object.get("ctix_created")),
        "ctix_modified": _to_stix_timestamp(ctix_object.get("ctix_modified")),
        "is_whitelist": bool(ctix_object.get("is_whitelist")),
        "is_deprecated": bool(ctix_object.get("is_deprecated")),
        "is_false_positive": bool(ctix_object.get("is_false_positive")),
        "is_revoked": bool(ctix_object.get("is_revoked")),
        "is_actioned": bool(ctix_object.get("is_actioned")),
        "country": ctix_object.get("country"),
        "severity": ctix_object.get("severity"),
        "sources": sorted({str(src.get("name")) for src in ctix_object.get("sources") or [] if src.get("name")}),
        "tags": list(dict.fromkeys(_get_names(ctix_object.get("tags")) + record_tags)),
        "manual_review": bool(lookup["manual_review"]) if lookup.get("manual_review") is not None else None,
        "relations": relations,
        "custom_attributes": _get_custom_attributes(ctix_object, enrichment),
        "enrichment": _get_enrichment_summary(enrichment),
        "first_seen": lookup.get("first_seen"),
        "last_seen": lookup.get("last_seen"),
        "indicator_url": "{}/ctix/threatdata/indicator/{}/overview".format(
            consts.CTIX_SERVER_URL[: -len("/ctixapi")] if consts.CTIX_SERVER_URL.endswith("/ctixapi")
            else consts.CTIX_SERVER_URL,
            ctix_object.get("id"),
        ),
    }
    # Sentinel drops keys without data; remove them here so stored objects match what is sent.
    extension = {key: value for key, value in extension.items() if value not in (None, "", [], {})}
    extension["relations"] = {key: names for key, names in relations.items() if names}
    if not extension["relations"]:
        del extension["relations"]
    return {consts.CTIX_EXTENSION_ID: extension}


def map_ctix_object_to_stix(ctix_object, record_tags=None, enrichment=None):
    """Convert a CTIX Saved Result Set (v3) indicator object into a STIX 2.1 indicator.

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.
        record_tags (list): Tag names ('ctix_tags') of the Saved Result Set record the object belongs to.
        enrichment (dict): Bulk IOC Lookup (Advanced) result of the indicator, or None.

    Returns:
        dict: STIX 2.1 indicator object.

    Raises:
        UnsupportedIndicatorException: If the object is not an indicator or its type is not supported.
    """
    if ctix_object.get("sdo_type") != consts.SUPPORTED_SDO_TYPE:
        raise UnsupportedIndicatorException("object type '{}' is not an indicator".format(ctix_object.get("sdo_type")))

    record_tags = record_tags or []
    pattern = _build_pattern(ctix_object)
    created = _to_stix_timestamp(ctix_object.get("created") or ctix_object.get("ctix_created"))
    if not created:
        raise UnsupportedIndicatorException("indicator has no creation time")
    modified_epoch = max(
        float(value)
        for value in (ctix_object.get("modified"), ctix_object.get("ctix_modified"), ctix_object.get("created"),
                      ctix_object.get("ctix_created"))
        if value not in (None, "")
    )
    modified = max(created, _to_stix_timestamp(modified_epoch))
    valid_from = _to_stix_timestamp(ctix_object.get("valid_from")) or created
    valid_until = _to_stix_timestamp(ctix_object.get("valid_until"))
    relations = _get_relations(ctix_object, enrichment)

    stix_indicator = {
        "type": "indicator",
        "spec_version": consts.STIX_SPEC_VERSION,
        "id": _get_stix_id(ctix_object),
        "created": created,
        "modified": modified,
        "created_by_ref": consts.CYWARE_IDENTITY_ID,
        "name": str(ctix_object.get("name") or ctix_object.get("sdo_name")),
        "indicator_types": [
            consts.INDICATOR_TYPE_BENIGN if ctix_object.get("is_whitelist") else consts.INDICATOR_TYPE_MALICIOUS
        ],
        "pattern": pattern,
        "pattern_type": "stix",
        "pattern_version": consts.STIX_SPEC_VERSION,
        "valid_from": valid_from,
        "revoked": bool(
            ctix_object.get("is_revoked")
            or ctix_object.get("is_deprecated")
            or ctix_object.get("is_false_positive")
            or ctix_object.get("is_whitelist")
        ),
        "external_references": [
            {
                "source_name": "Cyware CTIX",
                "external_id": str(ctix_object.get("id")),
                "description": "Severity: {}; Sources: {}".format(
                    ctix_object.get("severity") or "UNKNOWN",
                    ", ".join(
                        sorted({str(src.get("name")) for src in ctix_object.get("sources") or [] if src.get("name")})
                    )
                    or "None",
                ),
            }
        ],
        "extensions": _build_extension(ctix_object, record_tags, enrichment, relations),
    }
    if valid_until and valid_until > valid_from:
        stix_indicator["valid_until"] = valid_until
    confidence = _get_confidence(ctix_object)
    if confidence is not None:
        stix_indicator["confidence"] = confidence
    labels = list(dict.fromkeys(_get_names(ctix_object.get("tags")) + record_tags + relations["attack-pattern"]))
    if labels:
        stix_indicator["labels"] = labels
    tlp = _get_tlp(ctix_object)
    if tlp in consts.TLP_MARKING_DEFINITIONS:
        stix_indicator["object_marking_refs"] = [consts.TLP_MARKING_DEFINITIONS[tlp]]
    description = ctix_object.get("analyst_description") or (enrichment or {}).get("description")
    if description:
        stix_indicator["description"] = str(description)
    return stix_indicator
