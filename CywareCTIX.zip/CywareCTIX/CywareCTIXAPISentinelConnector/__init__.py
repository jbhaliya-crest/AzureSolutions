"""This is init file for CywareCTIXAPISentinelConnector Timer Trigger Function."""

import datetime
import time
import azure.functions as func
from SharedCode import consts
from SharedCode.logger import applogger
from SharedCode.cyware_ctix_exceptions import CywareCTIXTimeoutException
from CywareCTIXAPISentinelConnector.ctix_helper import CywareCTIXHelper


def main(mytimer: func.TimerRequest) -> None:
    """Run the Cyware CTIX indicator ingestion triggered by the timer.

    Args:
        mytimer (func.TimerRequest): The timer trigger request object.
    """
    start = time.time()
    applogger.info(
        "{} : {}, Function App started at {}".format(
            consts.LOGS_STARTS_WITH, consts.FUNCTION_NAME, datetime.datetime.fromtimestamp(start)
        )
    )
    if mytimer.past_due:
        applogger.info("{} : {}, The timer is past due.".format(consts.LOGS_STARTS_WITH, consts.FUNCTION_NAME))
    try:
        CywareCTIXHelper(int(start)).run()
    except CywareCTIXTimeoutException:
        applogger.info(
            "{} : {}, Function App stopped before its execution limit. Progress saved.".format(
                consts.LOGS_STARTS_WITH, consts.FUNCTION_NAME
            )
        )
    except Exception as error:
        applogger.error(
            "{} : {}, Function App encountered an error: {}".format(
                consts.LOGS_STARTS_WITH, consts.FUNCTION_NAME, error
            )
        )
        raise
    applogger.info(
        "{} : {}, Function App ended. Total time taken = {:.2f} seconds".format(
            consts.LOGS_STARTS_WITH, consts.FUNCTION_NAME, time.time() - start
        )
    )
