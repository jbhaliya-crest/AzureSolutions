"""This module orchestrates Cyware CTIX Saved Result Set collection and upload to Microsoft Sentinel."""

import inspect
import time
from collections import Counter
from SharedCode import consts
from SharedCode.logger import applogger
from SharedCode.cyware_ctix_exceptions import CywareCTIXException, CywareCTIXTimeoutException
from SharedCode.ctix_client import CywareCTIXClient
from SharedCode.ctix_to_stix_mapping import (
    UnsupportedIndicatorException,
    get_ioc_type,
    get_supported_ioc_types,
    map_ctix_object_to_stix,
    normalize_ioc_type,
)
from SharedCode.sentinel import MicrosoftSentinel
from SharedCode.state_manager import StateManager


class CywareCTIXHelper:
    """Fetch indicators from the CTIX Saved Result Set and upload them to Microsoft Sentinel.

    For each configured Saved Result Set label:
    - read the label's checkpoint (or start from the lookback window on the first run),
    - page through the Saved Result Set (v3) for the window [checkpoint, run time],
    - convert indicator objects to STIX 2.1 and upload them in batches of 100,
    - advance the checkpoint only after the whole window was processed successfully.
    """

    def __init__(self, start_time):
        """Initialize the helper and its clients.

        Args:
            start_time (int): Unix timestamp at which the function started.
        """
        self.start_time = start_time
        self.log_format = consts.LOG_FORMAT
        self._validate_environment_variables()
        self.labels = self._get_labels()
        self.ioc_types = self._get_ioc_types()
        self.ctix_client = CywareCTIXClient()
        self.sentinel_client = MicrosoftSentinel()
        self.state_manager = StateManager(
            connection_string=consts.CONN_STRING, table_name=consts.CHECKPOINT_TABLE_NAME
        )
        self.uploaded_indicators = {}
        self.stats = Counter()

    def _log(self, level, method_name, message):
        """Log a message in the connector's standard format.

        Args:
            level (str): Logger method name (info, warning, error, debug).
            method_name (str): Name of the calling method.
            message (str): Message to log.
        """
        getattr(applogger, level)(
            self.log_format.format(consts.LOGS_STARTS_WITH, method_name, consts.FUNCTION_NAME, message)
        )

    def _validate_environment_variables(self):
        """Validate that all required application settings are configured.

        Raises:
            CywareCTIXException: If a required application setting is missing.
        """
        __method_name = inspect.currentframe().f_code.co_name
        required = {
            "CTIX_SERVER_URL": consts.CTIX_SERVER_URL,
            "CTIX_ACCESS_ID": consts.CTIX_ACCESS_ID,
            "CTIX_SECRET_KEY": consts.CTIX_SECRET_KEY,
            "CTIX_SAVED_RESULT_SET_LABEL": consts.CTIX_SAVED_RESULT_SET_LABEL.strip(),
            "WORKSPACE_ID": consts.WORKSPACE_ID,
            "TENANT_ID": consts.TENANT_ID,
            "CLIENT_ID": consts.CLIENT_ID,
            "CLIENT_SECRET": consts.CLIENT_SECRET,
            "AzureWebJobsStorage": consts.CONN_STRING,
        }
        missing = [name for name, value in required.items() if not value]
        if missing:
            self._log("error", __method_name, "Missing required application settings: {}".format(", ".join(missing)))
            raise CywareCTIXException("Missing required application settings: {}".format(", ".join(missing)))
        if consts.CTIX_LOOKBACK_DAYS <= 0:
            raise CywareCTIXException("CTIX_LOOKBACK_DAYS must be a positive integer.")

    @staticmethod
    def _get_labels():
        """Get the Saved Result Set labels to collect.

        The Saved Result Set API accepts one exact, case-sensitive label per call, so a comma-separated
        setting is split and each label is collected with its own calls and checkpoint.

        Returns:
            list: Unique labels in configured order.
        """
        labels = [label.strip() for label in consts.CTIX_SAVED_RESULT_SET_LABEL.split(",")]
        return list(dict.fromkeys(label for label in labels if label))

    def _get_ioc_types(self):
        """Get the IOC types to collect from the CTIX_IOC_TYPES setting.

        Returns:
            set: Normalized IOC types to collect; empty to collect every supported type.

        Raises:
            CywareCTIXException: If a configured IOC type is not supported.
        """
        __method_name = inspect.currentframe().f_code.co_name
        configured = [ioc_type.strip() for ioc_type in consts.CTIX_IOC_TYPES.split(",") if ioc_type.strip()]
        if not configured:
            return set()
        supported = get_supported_ioc_types()
        supported_normalized = {normalize_ioc_type(ioc_type) for ioc_type in supported}
        unsupported = [ioc_type for ioc_type in configured if normalize_ioc_type(ioc_type) not in supported_normalized]
        if unsupported:
            message = "Unsupported IOC type(s) in CTIX_IOC_TYPES: {}. Supported values: {}.".format(
                ", ".join(unsupported), ", ".join(supported)
            )
            self._log("error", __method_name, message)
            raise CywareCTIXException(message)
        self._log("info", __method_name, "Collecting only IOC types: {}.".format(", ".join(configured)))
        return {normalize_ioc_type(ioc_type) for ioc_type in configured}

    def _check_timeout(self):
        """Raise when the function approaches the 10 minute execution limit.

        Raises:
            CywareCTIXTimeoutException: If the function has run for longer than 570 seconds.
        """
        elapsed = time.time() - self.start_time
        if elapsed >= consts.FUNCTION_APP_TIMEOUT_SECONDS:
            raise CywareCTIXTimeoutException("Function timeout reached at {} seconds".format(int(elapsed)))

    def run(self):
        """Collect every configured label.

        A failure of one label does not stop the others; the run is reported as failed at the end so the
        failed label's window is retried on the next trigger.

        Raises:
            CywareCTIXTimeoutException: If the function approaches its execution limit.
            CywareCTIXException: If at least one label failed.
        """
        __method_name = inspect.currentframe().f_code.co_name
        failed_labels = []
        for label in self.labels:
            try:
                self._process_label(label)
            except CywareCTIXTimeoutException:
                self._log_summary()
                raise
            except Exception as error:
                failed_labels.append(label)
                self._log(
                    "error",
                    __method_name,
                    "Label '{}' failed; its checkpoint was not advanced and the window will be retried on the "
                    "next run. Error: {}".format(label, error),
                )
        self._log_summary()
        if failed_labels:
            raise CywareCTIXException("Ingestion failed for label(s): {}".format(", ".join(failed_labels)))

    def _get_window(self, label):
        """Get the time window and start page to process for a label.

        Args:
            label (str): Saved Result Set label.

        Returns:
            tuple: (from_timestamp, to_timestamp, page, is_first_run).
        """
        now = int(time.time())
        checkpoint = self.state_manager.get(label)
        if not checkpoint:
            return now - consts.CTIX_LOOKBACK_DAYS * 86400, now, 1, True
        if checkpoint.get("to_timestamp"):
            # Resume a window that a previous run could not finish before its timeout.
            return checkpoint["from_timestamp"], checkpoint["to_timestamp"], checkpoint["page"], False
        return checkpoint["from_timestamp"], now, 1, False

    def _process_label(self, label):
        """Collect, convert and upload all Saved Result Set records of a label for its current window.

        Args:
            label (str): Saved Result Set label.

        Raises:
            CywareCTIXTimeoutException: If the function approaches its execution limit (progress is saved).
        """
        __method_name = inspect.currentframe().f_code.co_name
        from_timestamp, to_timestamp, page, is_first_run = self._get_window(label)
        if from_timestamp > to_timestamp:
            self._log("info", __method_name, "Label '{}': nothing to collect yet.".format(label))
            return
        self._log(
            "info",
            __method_name,
            "Label '{}': collecting records published between {} and {} starting at page {}.".format(
                label, from_timestamp, to_timestamp, page
            ),
        )
        seen_records = set()
        cursor = from_timestamp
        while True:
            try:
                self._check_timeout()
                records, has_next, total = self.ctix_client.get_saved_result_set_page(
                    label, cursor, to_timestamp, page
                )
                if page == 1 and total == 0 and is_first_run:
                    self._log(
                        "warning",
                        __method_name,
                        "Label '{}' returned no records. Verify that a CTIX rule with the 'Save Result Set V3' "
                        "action uses this exact (case-sensitive) label.".format(label),
                    )
                processed_before = len(seen_records)
                stix_indicators = self._map_records(records, seen_records)
            except CywareCTIXTimeoutException:
                # The current page was not uploaded yet, so the next run resumes at this page.
                self.state_manager.post(label, cursor, to_timestamp, page)
                self._log(
                    "warning",
                    __method_name,
                    "Label '{}': stopping before the execution limit; the next run resumes at page {}.".format(
                        label, page
                    ),
                )
                raise
            self.stats["records"] += len(seen_records) - processed_before
            if stix_indicators:
                result = self.sentinel_client.upload_indicators(stix_indicators)
                self.stats["uploaded"] += result["success_count"]
                self.stats["failed_validation"] += result["failure_count"]
            self._log(
                "info",
                __method_name,
                "Label '{}': page {} processed ({} records, {} indicators uploaded).".format(
                    label, page, len(records), len(stix_indicators)
                ),
            )
            if not has_next:
                break
            # CTIX sorts records only by timestamp, so records published in the same second can move between
            # pages. Restart from the last record's timestamp at page 1; records already processed are skipped.
            last_timestamp = int(records[-1].get("timestamp") or cursor) if records else cursor
            if last_timestamp > cursor:
                cursor, page = last_timestamp, 1
            else:
                page += 1
                self._log(
                    "warning",
                    __method_name,
                    "Label '{}': more than {} records were published in second {}; records of this second may "
                    "be missed or repeated across pages.".format(label, consts.CTIX_PAGE_SIZE, cursor),
                )
        # Both timestamps are inclusive, so the next window starts one second after this one.
        self.state_manager.post(label, to_timestamp + 1, None, 1)

    def _map_records(self, records, seen_records):
        """Convert the indicator objects of Saved Result Set records to STIX, removing duplicates.

        1. Select the supported indicator objects (latest version per indicator, tags of all records merged).
        2. Fetch their enrichment fields from the Bulk IOC Lookup API when enabled.
        3. Map each indicator with its record tags and enrichment result.

        Args:
            records (list): Saved Result Set (v3) records.
            seen_records (set): Record ids already processed in this window.

        Returns:
            list: STIX indicators to upload.

        Raises:
            CywareCTIXAPIException: If the enrichment lookup fails after retries; the page is then not uploaded,
                so indicators uploaded earlier with enrichment are not replaced by rows without it.
        """
        __method_name = inspect.currentframe().f_code.co_name
        candidates = {}
        skipped = Counter()
        for record in records:
            record_id = record.get("id")
            if record_id in seen_records:
                continue
            seen_records.add(record_id)
            data = record.get("data")
            if record.get("version") != consts.CTIX_SAVED_RESULT_SET_VERSION or not isinstance(data, list):
                skipped["record version '{}' (only v3 is supported)".format(record.get("version"))] += 1
                continue
            record_tags = [str(tag.get("name")) for tag in record.get("ctix_tags") or [] if tag.get("name")]
            for ctix_object in data:
                if not isinstance(ctix_object, dict):
                    continue
                try:
                    stix_indicator = map_ctix_object_to_stix(ctix_object)
                except UnsupportedIndicatorException as error:
                    skipped[str(error)] += 1
                    continue
                except (TypeError, ValueError, KeyError) as error:
                    skipped["malformed object"] += 1
                    self._log(
                        "debug",
                        __method_name,
                        "Skipped malformed object {}: {}".format(ctix_object.get("id"), error),
                    )
                    continue
                ioc_type = get_ioc_type(ctix_object)
                if self.ioc_types and normalize_ioc_type(ioc_type) not in self.ioc_types:
                    skipped["IOC type '{}' is not selected in IOC Types".format(ioc_type)] += 1
                    continue
                stix_id, modified = stix_indicator["id"], stix_indicator["modified"]
                if self.uploaded_indicators.get(stix_id, "") >= modified:
                    self.stats["duplicates"] += 1
                    continue
                candidate = candidates.setdefault(stix_id, {"object": ctix_object, "modified": modified, "tags": []})
                if candidate["modified"] < modified:
                    candidate.update({"object": ctix_object, "modified": modified})
                candidate["tags"] = list(dict.fromkeys(candidate["tags"] + record_tags))
        for reason, count in skipped.items():
            self.stats["skipped"] += count
            self._log("warning", __method_name, "Skipped {} object(s): {}".format(count, reason))

        enrichments = self._get_enrichments([candidate["object"].get("id") for candidate in candidates.values()])
        indicators = []
        for stix_id, candidate in candidates.items():
            indicators.append(
                map_ctix_object_to_stix(
                    candidate["object"], candidate["tags"], enrichments.get(candidate["object"].get("id"))
                )
            )
            self.uploaded_indicators[stix_id] = candidate["modified"]
        return indicators

    def _get_enrichments(self, object_ids):
        """Fetch the enrichment fields (relations, custom attributes, enrichment data, manual review) of indicators.

        Args:
            object_ids (list): CTIX indicator object ids.

        Returns:
            dict: Bulk IOC Lookup result per CTIX object id; empty when 'Fetch Enriched Data' is disabled.
        """
        __method_name = inspect.currentframe().f_code.co_name
        if not consts.CTIX_FETCH_ENRICHED_DATA or not object_ids:
            return {}
        enrichments = {}
        for start in range(0, len(object_ids), consts.CTIX_BULK_LOOKUP_BATCH_SIZE):
            self._check_timeout()
            batch = object_ids[start:start + consts.CTIX_BULK_LOOKUP_BATCH_SIZE]
            enrichments.update(self.ctix_client.bulk_lookup_indicators(batch))
        missing = len(set(object_ids) - set(enrichments))
        if missing:
            self._log(
                "info",
                __method_name,
                "{} of {} indicator(s) were not returned by the enrichment lookup; they are uploaded without "
                "enrichment fields.".format(missing, len(object_ids)),
            )
        self.stats["enriched"] += len(enrichments)
        return enrichments

    def _log_summary(self):
        """Log the run statistics."""
        __method_name = inspect.currentframe().f_code.co_name
        self._log(
            "info",
            __method_name,
            "Run summary: records={}, indicators enriched={}, indicators uploaded={}, failed validation={}, "
            "skipped={}, duplicates={}".format(
                self.stats["records"],
                self.stats["enriched"],
                self.stats["uploaded"],
                self.stats["failed_validation"],
                self.stats["skipped"],
                self.stats["duplicates"],
            ),
        )
